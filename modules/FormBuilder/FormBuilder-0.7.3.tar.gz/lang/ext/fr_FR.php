<?php
$lang['friendlyname'] = 'Formulaires (Form Builder)';
$lang['field_type_DispositionEmailFromFEUProperty'] = '*Envoyer aux utilisateurs FEU qui correspondent &agrave; une certaine propri&eacute;t&eacute;';
$lang['field_type_'] = 'Type de champ non renseign&eacute;';
$lang['field_type_CatalogerItemsField'] = 'S&eacute;lectionner un (ou plusieurs) items de Cataloger';
$lang['field_type_FieldsetEnd'] = '-Fin de champ renseign&eacute;';
$lang['field_type_FieldsetStart'] = '-D&eacute;but de champ renseign&eacute;';
$lang['field_type_TextField'] = 'Ligne de texte simple';
$lang['field_type_HTML5NumberField'] = 'Entr&eacute;e Nombre HTML5';
$lang['field_type_HTML5EmailField'] = 'Entr&eacute;e Email HTML5';
$lang['field_type_HTML5URLField'] = 'Entr&eacute;e URL HTML5';
$lang['field_type_SiteAdminField'] = 'Administration du site';
$lang['field_type_PasswordField'] = 'Mot de passe';
$lang['field_type_PasswordAgainField'] = 'Mot de passe (&agrave; nouveau pour v&eacute;rification)';
$lang['field_type_TextFieldExpandable'] = 'Lignes de texte multiples';
$lang['field_type_TextAreaField'] = 'Zone de texte';
$lang['field_type_ButtonField'] = 'Bouton';
$lang['field_type_CheckboxField'] = 'Bo&icirc;te &agrave; cocher';
$lang['field_type_CheckboxGroupField'] = 'Groupe de bo&icirc;tes &agrave; cocher';
$lang['field_type_PulldownField'] = 'Menu d&eacute;roulant';
$lang['field_type_YearPullDownField'] = 'Menu d&eacute;roulant ann&eacute;e';
$lang['field_type_MultiselectField'] = 'S&eacute;lection multiple';
$lang['field_type_StatePickerField'] = 'S&eacute;lectionner un &eacute;tat des USA';
$lang['field_type_ProvincePickerField'] = 'S&eacute;lectionner une Province du Canada';
$lang['field_type_CountryPickerField'] = 'S&eacute;lectionner un pays';
$lang['field_type_DatePickerField'] = 'S&eacute;lectionner une date';
$lang['field_type_TimePickerField'] = 'S&eacute;lectionner une heure';
$lang['field_type_RadioGroupField'] = 'Groupe de boutons radio';
$lang['field_type_DispositionDirector'] = '*Adresser par mail les r&eacute;sultats apr&egrave;s choix par menu d&eacute;roulant';
$lang['field_type_DispositionFileDirector'] = '*Sauvegarder les r&eacute;sultats vers un fichier apr&egrave;s choix par menu d&eacute;roulant';
$lang['field_type_DispositionMultiselectFileDirector'] = '*Sauvegarder en fichier(s) les r&eacute;sultats des s&eacute;lections multiples';
$lang['field_type_DispositionPageRedirector'] = '*Rediriger vers la page &agrave; partir d&#039;un menu d&eacute;roulant';
$lang['field_type_DispositionEmail'] = '*Envoyer par mail les r&eacute;sultats aux adresses fournies';
$lang['field_type_DispositionEmailConfirmation'] = '*Validation via adresse mail';
$lang['field_type_DispositionFromEmailAddressField'] = '*Mail champ &quot;From Address&quot;, et envoie copie';
$lang['field_type_DispositionFile'] = '*&Eacute;crire les r&eacute;sultats dans un fichier';
$lang['field_type_DispositionUniqueFile'] = '*Ecrire les r&eacute;sultats vers un fichier &agrave; chaque soumission';
$lang['field_type_DispositionDatabase'] = '*Stocker les r&eacute;sultats dans la base de donn&eacute;es';
$lang['field_type_DispositionFormBrowser'] = '*Stocker les r&eacute;sultats pour le module FormBrowser v0.3/v0.4';
$lang['field_type_DispositionUserTag'] = '*Appeler une balise utilisateur avec le formulaire r&eacute;sultats';
$lang['field_type_DispositionForm'] = '*Soumettre &agrave; une quelconque forme d&#039;action';
$lang['field_type_DispositionDeliverToEmailAddressField'] = '*Envoyer par mail aux utilisateurs ayant fourni une adresse';
$lang['field_type_DispositionEmailSiteAdmin'] = '*Mail vers l&#039;administrateur du CMS';
$lang['field_type_DispositionEmailBasedFrontendFields'] = '*Envoyer par e-mail en fonction des champs saisis';
$lang['field_type_PageBreakField'] = '-Saut de page';
$lang['field_type_FileUploadField'] = 'Fichier &agrave; envoyer';
$lang['field_type_FromEmailAddressField'] = 'Champ du mail &quot;From Adresse&quot;';
$lang['field_type_FromEmailAddressAgainField'] = 'Champ du mail &quot;From Adresse&quot; &agrave; nouveau';
$lang['field_type_FromEmailNameField'] = 'Champ du mail &quot;From Nom&quot;';
$lang['field_type_FromEmailSubjectField'] = 'Champ du mail &quot;Sujet&quot;';
$lang['field_type_CCEmailAddressField'] = 'Champ du mail en Copie Conforme (CC)';
$lang['field_type_StaticTextField'] = '-Texte statique';
$lang['field_type_SystemLinkField'] = '-Lien statique';
$lang['field_type_LinkField'] = 'Lien (utilisateur connu)';
$lang['field_type_HiddenField'] = '-Champ cach&eacute;';
$lang['field_type_ComputedField'] = '-Champ calcul&eacute;';
$lang['field_type_UniqueIntegerField'] = '-Entier unique (S&eacute;rie)';
$lang['field_type_UserTagField'] = '-Appeler une balise utilisateur';
$lang['field_type_CompanyDirectoryField'] = 'Champ Company Directory';
$lang['field_type_ModuleInterfaceField'] = '-Champ Module Interface';
$lang['field_type_CheckboxExtendedField'] = 'case de validation &eacute;tendue';
$lang['validation_none'] = 'Sans Validation';
$lang['validation_numeric'] = 'Num&eacute;rique';
$lang['validation_integer'] = 'Entier';
$lang['validation_email_address'] = 'Adresse mail';
$lang['validation_usphone'] = 'Num&eacute;ro de t&eacute;l&eacute;phone (US)';
$lang['validation_must_check'] = 'Doit &ecirc;tre v&eacute;rifi&eacute;';
$lang['validation_regex_match'] = 'Valider l&#039;expression reguli&egrave;re';
$lang['validation_regex_nomatch'] = 'Ne pas valider l&#039;expression reguli&egrave;re';
$lang['validation_empty'] = 'Ne peut &ecirc;tre vide';
$lang['required'] = 'N&eacute;cessaire';
$lang['not_required'] = 'Facultatif';
$lang['not_available'] = 'Non disponible';
$lang['error_emailfromfeuprop'] = 'Erreur lors du param&eacute;trage du champ';
$lang['error_nofeu'] = 'Le module Gestion des utilisateurs du site (FrontEndUsers) n&#039;a pas &eacute;t&eacute; trouv&eacute;. Ce champ ne fonctionnera pas.';
$lang['error_nofeudefns'] = 'Aucune propri&eacute;t&eacute; FEU trouv&eacute;e. Ce champ ne fonctionnera pas.';
$lang['required_field_missing'] = 'Un champ obligatoire n&#039;a pas &eacute;t&eacute; rempli';
$lang['please_enter_a_value'] = 'Veuillez entrer une valeur pour &quot;%s&quot;';
$lang['please_enter_a_number'] = 'Veuillez entrer un nombre pour &quot;%s&quot;';
$lang['please_enter_valid'] = 'Veuillez entrer une valeur correcte pour &quot;%s&quot;';
$lang['please_enter_an_integer'] = 'Veuillez entrer une valeur enti&egrave;re pour &quot;%s&quot;';
$lang['please_enter_an_email'] = 'Veuillez entrer une adresse mail valide pour &quot;%s&quot;';
$lang['email_address_does_not_match'] = 'L&#039;adresse mail ne correspond pas &agrave; la valeur de &quot;% s&quot;';
$lang['please_enter_a_phone'] = 'Veuillez entrer un num&eacute;ro de t&eacute;l&eacute;phone valide pour &quot;%s&quot;';
$lang['please_login'] = 'Merci de vous connectez avec ce formulaire';
$lang['not_valid_email'] = '&quot;%s&quot; ne semble pas &ecirc;tre une adresse mail valide !';
$lang['please_enter_no_longer'] = 'Veuillez entrer une valeur ayant moins de %s caract&egrave;res';
$lang['please_enter_at_least'] = 'Veuillez entrer une valeur au minimum de % s caract&egrave;res';
$lang['title_list_delimiter'] = 'Caract&egrave;re utilis&eacute; comme &quot;s&eacute;parateur&quot; dans les formulaires re&ccedil;us contenant plus d&#039;une valeur&nbsp;';
$lang['you_need_permission'] = 'Il vous faut la permission &quot;%s&quot; pour ex&eacute;cuter cette op&eacute;ration.';
$lang['lackpermission'] = 'D&eacute;sol&eacute; ! Vous n&#039;avez pas les droits suffisants pour acc&eacute;der &agrave; cette section.';
$lang['field_order_updated'] = 'Ordre des champs mis &agrave; jour.';
$lang['form_deleted'] = 'Formulaire supprim&eacute;.';
$lang['field_deleted'] = 'Champ supprim&eacute;.';
$lang['configuration_updated'] = 'Configuration mise &agrave; jour.';
$lang['you_must_check'] = 'V&eacute;rifiez &quot;%s&quot; pour pouvoir continuer.';
$lang['must_specify_one_destination'] = 'Vous devez pr&eacute;ciser au moins une adresse de destination !';
$lang['are_you_sure_delete_form'] = 'Voulez-vous vraiment supprimer le formulaire %s ?';
$lang['are_you_sure_delete_field'] = 'Voulez-vous vraiment supprimer le champ %s ?';
$lang['notice_select_type'] = 'Les options avanc&eacute;es ne seront disponibles que lorsque qu&#039;un type de champ aura &eacute;t&eacute; choisi.';
$lang['field_name_in_use'] = 'Il existe d&eacute;j&agrave; un champ &quot;%s&quot; utilis&eacute;. Utilisez des noms de champ uniques ou d&eacute;sactivez cette fonction dans la configuration de Form Builder.';
$lang['field_no_name'] = 'Tous les champs doivent &ecirc;tre nomm&eacute;s, sinon d&eacute;sactivez cette fonction dans la configuration de Form Builder.';
$lang['no_field_assigned'] = 'Aucun champ d&eacute;sign&eacute; pour %s';
$lang['anonymous'] = 'Anonyme';
$lang['abbreviation_length'] = 'Longueur : %s';
$lang['boxes'] = '%s bo&icirc;tes';
$lang['options'] = '%s options ';
$lang['text_length'] = '%s caract&egrave;res.';
$lang['order'] = 'Ordre';
$lang['unspecified'] = '[non sp&eacute;cifi&eacute;]';
$lang['added'] = 'ajout&eacute;';
$lang['updated'] = 'mis &agrave; jour';
$lang['sort_options'] = 'Trier les options &agrave; l&#039;ex&eacute;cution&nbsp;';
$lang['select_one'] = 'S&eacute;lectionnez-en un';
$lang['select_type'] = 'S&eacute;lectionnez le type';
$lang['to'] = 'Pour';
$lang['yes'] = 'Oui';
$lang['no'] = 'Non';
$lang['recipients'] = 'destinataires';
$lang['fields'] = 'champs';
$lang['file_count'] = '%s fichiers possibles';
$lang['destination_count'] = '%s destinations ';
$lang['save'] = 'Sauvegarder';
$lang['add'] = 'Ajouter';
$lang['update'] = 'Mise &agrave; jour';
$lang['save_and_continue'] = 'Sauvegarder et continuer l&#039;&eacute;dition';
$lang['information'] = 'Information ';
$lang['automatic'] = 'Automatique';
$lang['forms'] = 'Formulaires';
$lang['form'] = 'Formulaire %s';
$lang['configuration'] = 'Configuration ';
$lang['field_requirement_updated'] = 'Champ requis mis &agrave; jour.';
$lang['maximum_size'] = 'Taille Maximum';
$lang['permitted_extensions'] = 'Extensions ';
$lang['permitted_filetypes'] = 'Types de fichier autoris&eacute;s';
$lang['file_too_large'] = 'Fichier envoy&eacute; trop lourd ! La taille maximum est de :&nbsp;';
$lang['illegal_file_type'] = 'Ce type de fichier n&#039;est pas accept&eacute;. Veuillez v&eacute;rifier l&#039;extension de votre fichier.';
$lang['upload'] = 'Envoi';
$lang['form_imported'] = 'Formulaire Import&eacute;.';
$lang['form_import_failed'] = 'L&#039;importation du formulaire a &eacute;chou&eacute; ! Il y a un probl&egrave;me avec le format du fichier XML.';
$lang['rows'] = '%s lignes';
$lang['cols'] = '%s colonnes';
$lang['12_hour'] = 'Sur 12 heures';
$lang['24_hour'] = 'Sur 24 heures';
$lang['hour'] = 'Heure';
$lang['min'] = 'Minute ';
$lang['merid'] = 'M&eacute;ridien';
$lang['date_range'] = 'Ordre : %s - %s';
$lang['thanks'] = 'Merci ! Votre formulaire a &eacute;t&eacute; re&ccedil;u.';
$lang['edit'] = 'Editer';
$lang['delete'] = 'Supprimer';
$lang['day'] = 'Jour';
$lang['mon'] = 'Mois';
$lang['year'] = 'Ann&eacute;e';
$lang['none'] = '(Aucun)';
$lang['css'] = 'CSS ';
$lang['uninstalled'] = 'Module d&eacute;sinstall&eacute;.';
$lang['installed'] = 'Module version %s install&eacute;e.';
$lang['upgraded'] = 'Module mis &agrave; jour &agrave; la version %s.';
$lang['button_previous'] = 'Retour...';
$lang['button_submit'] = 'Envoyer';
$lang['button_continue'] = 'Suivant...';
$lang['value_checked'] = 'V&eacute;rifi&eacute;';
$lang['value_unchecked'] = 'Non v&eacute;rifi&eacute;';
$lang['tab_main'] = 'Principal';
$lang['tab_symbol'] = 'Param&egrave;tres d&#039;affichage du Formulaire';
$lang['tab_submit'] = 'Envoi du Formulaire';
$lang['tab_captcha'] = 'Options Captcha ';
$lang['tab_advanced'] = 'Options avanc&eacute;es';
$lang['tab_templatelayout'] = 'Gabarit du Formulaire';
$lang['tab_submissiontemplate'] = 'Gabarit de l&#039;envoi';
$lang['tab_udt'] = 'Integration balise utilisateur';
$lang['title_feu_property'] = 'Propri&eacute;t&eacute; FrontEndUsers';
$lang['info_feu_property'] = 'Seulement certains types de propri&eacute;t&eacute; peuvent &ecirc;tre utilis&eacute;s pour corroborer (menus d&eacute;roulant, champs de s&eacute;lection multiple, etc.).';
$lang['canuse_smarty'] = '<em>Les variables Smarty sont actives dans ce champ.</em>';
$lang['add_options'] = 'Ajouter plus d&#039;options';
$lang['delete_options'] = 'Supprimer les options s&eacute;lectionn&eacute;es';
$lang['add_checkboxes'] = 'Ajouter d&#039;autres bo&icirc;tes de v&eacute;rification';
$lang['delete_checkboxes'] = 'Supprimer les bo&icirc;tes de v&eacute;rification s&eacute;lectionn&eacute;es';
$lang['add_address'] = 'Ajouter d&#039;autres adresses mail';
$lang['delete_address'] = 'Supprimer les adresses mail s&eacute;lectionn&eacute;es';
$lang['add_destination'] = 'Ajouter d&#039;autres destinations';
$lang['delete_destination'] = 'Supprimer les destinations s&eacute;lectionn&eacute;es';
$lang['suspected_spam'] = 'Trop de mails sont g&eacute;n&eacute;r&eacute;s &agrave; partir de votre adresse IP ! Le syst&egrave;me anti-spam a &eacute;t&eacute; activ&eacute; et les administrateurs du site en ont &eacute;t&eacute; inform&eacute;s.';
$lang['suspected_spam_log'] = 'De possibles spams provenant de l&#039;IP %s ont &eacute;t&eacute; stopp&eacute;s.';
$lang['reorder'] = 'R&eacute;organiser les champs';
$lang['cancel'] = 'Annul&eacute;';
$lang['value_set'] = 'Valeur donn&eacute;e : %s';
$lang['help_cataloger_attribute_fields'] = 'Below is a list of the attributes available from the Cataloger module.<br/>You can optionally specify valid ranges, values, or numerous values to be used in filtering the list of items that is displayed to the user.<br/>
<br/>
<strong>Ranges:</strong><br/>
Ranges can be specified by signifying a minimum and maximum value using this syntax: &amp;quot;range: minvalue to maxvalue&amp;quot;<br/>
<br/>
<strong>Multiple Values:</strong><br/>
To specify multiple values for an attribute use the syntax &amp;quot;multi: value1|value2|value3&amp;quot;<br/>
<br/>
<strong>Values from hidden fields</strong><br/>
To specify a value from a hidden field use the syntax {$fld_id}<br/>
<br/>';
$lang['title_textfield_label'] = 'Intitul&eacute; de champ de texte';
$lang['title_show_textfield'] = 'Montrer un champ texte ?';
$lang['help_name_regex'] = 'Une expression reguli&egrave;re pour filtrer par nom les items de Cataloger';
$lang['help_field_height'] = 'La hauteur du champ multiple';
$lang['title_name_regex'] = 'Nom de l&#039;expression reguli&egrave;re pour Cataloger';
$lang['title_field_height'] = 'Hauteur du champ';
$lang['title_file_path'] = 'Dossier de destination pour les fichiers cr&eacute;es&nbsp;';
$lang['title_udt_name'] = 'Balise utilisateur&nbsp;';
$lang['title_uploads_destpage'] = 'Page de retour pour les liens d&#039;uploads (envois)';
$lang['title_uploadmodule_summary'] = 'Envoy&eacute; avec formbuilder';
$lang['title_uploads_category'] = 'Cat&eacute;gorie d&#039;Uploads (envois)';
$lang['title_sendto_uploads'] = 'Envoyer ce fichier au module d&#039;upload';
$lang['title_allow_overwrite'] = 'Autoriser l&#039;&eacute;crasemement des fichiers d&eacute;j&agrave; existants lors de l&#039;upload ?';
$lang['title_allow_overwrite_long'] = 'Le fichier upload&eacute; doit-il &eacute;craser le fichier pr&eacute;c&eacute;demment upload&eacute; s&#039;il a le m&ecirc;me nom ?';
$lang['overwrite'] = 'Permet le remplacement';
$lang['nooverwrite'] = 'Non remplac&eacute;';
$lang['file_already_exists'] = 'Le fichier %s existe d&eacute;j&agrave;, et ne peut pas &ecirc;tre &eacute;cras&eacute;.';
$lang['title_file_rename'] = 'Nom du fichier gabarit';
$lang['original_file_extension'] = 'Extension originale du fichier (le &quot;.&quot; compris)';
$lang['title_suppress_filename'] = 'Supprimer le nom de fichier dans des les mails et dans les formulaires pour l&#039;utilisateur final';
$lang['title_suppress_attachment'] = 'Emp&ecirc;cher d&#039;attacher des fichiers aux emails';
$lang['file_rename_help'] = 'Pour renommer un fichier pour l&#039;upload, cr&eacute;ez le gabarit ici. Laissez vide pour pr&eacute;server le nom du fichier original';
$lang['title_legend'] = 'L&eacute;gende&nbsp;';
$lang['title_maximum_length'] = 'Longueur maximum&nbsp;';
$lang['title_checkbox_label'] = 'Intitul&eacute; de la case&nbsp;';
$lang['title_radio_label'] = 'Intitul&eacute; du bouton radio';
$lang['title_checked_value'] = 'Valeur v&eacute;rifi&eacute;e&nbsp;';
$lang['title_unchecked_value'] = 'Valeur non-v&eacute;rifi&eacute;e&nbsp;';
$lang['title_checkbox_details'] = 'D&eacute;tails des groupes de cases de v&eacute;rification&nbsp;';
$lang['title_delete'] = 'Supprimer ?';
$lang['title_select_one_message'] = 'Texte personnalisable &quot;s&eacute;lection&quot;&nbsp;';
$lang['title_selection_value'] = 'Valeur s&eacute;lectionn&eacute;e';
$lang['title_selection_displayname'] = 'Nom d&#039;affichage s&eacute;lectionn&eacute;&nbsp;';
$lang['title_selection_subject'] = 'Sujet s&eacute;lectionn&eacute;';
$lang['title_select_default_country'] = 'S&eacute;lection par d&eacute;faut&nbsp;';
$lang['title_select_default_state'] = 'S&eacute;lection par d&eacute;faut&nbsp;';
$lang['title_select_default_province'] = 'S&eacute;lection par d&eacute;faut&nbsp;';
$lang['title_option_name'] = 'Nom de l&#039;option';
$lang['title_option_value'] = 'Valeur soumise';
$lang['title_pulldown_details'] = 'Options par menu d&eacute;roulant&nbsp;';
$lang['title_multiselect_details'] = 'Options de S&eacute;lection multiple&nbsp;';
$lang['title_destination_address'] = 'Adresse mail de destination&nbsp;';
$lang['title_destination_filename'] = 'Nom du fichier de destination&nbsp;';
$lang['title_email_from_name'] = '&quot;From Nom&quot; pour le mail&nbsp;';
$lang['title_relaxed_email_regex'] = 'Validation adresse mail plus souple&nbsp;';
$lang['title_relaxed_regex_long'] = 'Autoriser les adresses mail sans extension (c.a.d : accepter &quot;nom@domaine&quot; &agrave; la place de &quot;nom@domaine.com&quot; requis par d&eacute;faut)';
$lang['title_email_from_address'] = '&quot;From Adresse&quot; pour Mail de l&#039;exp&eacute;diteur&nbsp;';
$lang['title_email_encoding'] = 'Encodage des caract&egrave;res du mail&nbsp;';
$lang['title_director_details'] = 'Menu d&eacute;roulant bas&eacute; sur les d&eacute;tails de l&#039;email&nbsp;';
$lang['title_file_name'] = 'Nom du fichier&nbsp;';
$lang['title_email_subject'] = 'Ligne du sujet dans le mail&nbsp;';
$lang['title_form_name'] = 'Nom du Formulaire&nbsp;';
$lang['title_form_status'] = 'Statut du Formulaire&nbsp;';
$lang['title_ready_for_deployment'] = 'Pr&ecirc;t &agrave; &ecirc;tre d&eacute;ploy&eacute;';
$lang['title_not_ready1'] = 'Pas pr&ecirc;t';
$lang['title_redirect_page'] = 'Page de redirection apr&egrave;s l&#039;envoi du formulaire&nbsp;';
$lang['title_not_ready2'] = 'Ajouter un champ au formulaire pour pouvoir modifier les contributions des utilisateurs.';
$lang['title_not_ready_link'] = 'Utiliser ce raccourci';
$lang['title_form_alias'] = 'Alias du Formulaire&nbsp;';
$lang['title_field_alias_short'] = 'Alias ';
$lang['title_form_fields'] = 'Champs du Formulaire&nbsp;';
$lang['title_field_id'] = 'ID du champ&nbsp;';
$lang['title_show_fieldaliases'] = 'Montrer les champs Alias&nbsp;';
$lang['title_show_fieldaliases_long'] = 'Cocher cette case montrera les champs Alias lors de l&#039;&eacute;dition de ce formulaire';
$lang['title_field_name'] = 'Nom de champ&nbsp;';
$lang['title_field_alias'] = 'Alias du champ et Id DOM (id CSS)&nbsp;';
$lang['title_radiogroup_details'] = 'D&eacute;tails des groupes de boutons radio&nbsp;';
$lang['title_field_type'] = 'Type de champ&nbsp;';
$lang['title_not_ready3'] = 'pour cr&eacute;er un formulaire rapidement.';
$lang['title_add_new_form'] = 'Ajouter un nouveau formulaire';
$lang['title_show_version'] = 'Montrer la version de Form Builder ?&nbsp;';
$lang['title_show_version_long'] = 'Cela indiquera dans un commentaire la version install&eacute;e du module Form Builder. Parfois utile pour d&eacute;bugger.';
$lang['title_add_new_field'] = 'Ajouter un nouveau champ';
$lang['title_form_submit_button'] = 'Texte du bouton d&#039;envoi du formulaire&nbsp;';
$lang['title_button_text'] = 'Texte du bouton';
$lang['title_submit_button_safety'] = 'Ajouter du Javascript au bouton d&#039;envoi final pour aider &agrave; la pr&eacute;vention des envois multiples (spam) ?';
$lang['title_submit_button_safety_help'] = 'Ajouter un script s&eacute;curis&eacute;&nbsp;';
$lang['title_form_next_button'] = 'Texte du bouton &quot;suivant&quot; du formulaire (utilis&eacute; pour les formulaires comprenant plusieurs pages)&nbsp;';
$lang['title_form_prev_button'] = 'Texte du bouton &quot;pr&eacute;c&eacute;dent&quot; du formulaire (utilis&eacute; pour les formulaires comprenant plusieurs pages)&nbsp;';
$lang['title_field_validation'] = 'Validation du champ&nbsp;';
$lang['title_field_to_validate'] = 'Champ &agrave; valider&nbsp;';
$lang['title_field_css_id'] = 'Id CSS pour ce champ&nbsp;';
$lang['title_form_css_class'] = 'Classe CSS de ce formulaire&nbsp;';
$lang['title_field_css_class'] = 'Classe CSS de ce champ&nbsp;';
$lang['title_form_predisplay_udt'] = 'Balise utilisateur &agrave; appeler avant d&#039;afficher le formulaire la premi&egrave;re fois (appel&eacute;e une seule fois)&nbsp;';
$lang['title_form_predisplay_each_udt'] = 'Balise utilisateur &agrave; appeler avant d&#039;afficher le formulaire (appel&eacute;e &agrave; chaque page pour les formulaires multipages)&nbsp;';
$lang['title_form_validate_udt'] = 'Balise utilisateur &agrave; appeler pendant la validation du formulaire&nbsp;';
$lang['title_form_required_symbol'] = 'Symbole indiquant un champ obligatoire&nbsp;';
$lang['title_field_required'] = 'Requis&nbsp;';
$lang['title_field_required_long'] = 'Ce champ exige une r&eacute;ponse obligatoire&nbsp;';
$lang['title_hide_label'] = 'Intitul&eacute; cach&eacute;&nbsp;';
$lang['title_hide_label_long'] = 'Masquer le nom de ce champ dans le formulaire';
$lang['title_textarea_length'] = 'La longueur maximale du contenu d&#039;un champ (0 ou vide pas de limite)';
$lang['title_text'] = 'Texte statique &agrave; afficher&nbsp;';
$lang['title_field_regex'] = 'Validation Regex&nbsp;';
$lang['title_lines_to_show'] = 'Nombre de lignes &agrave; afficher&nbsp;';
$lang['title_read_only'] = 'Lecture seule';
$lang['no_default'] = 'Pas de s&eacute;lection par d&eacute;faut&nbsp;';
$lang['redirect_after_approval'] = 'Page de redirection apr&egrave;s acceptation&nbsp;';
$lang['title_regex_help'] = 'Cette expression r&eacute;guli&egrave;re sera seulement utilis&eacute;e si &quot;type de validation&quot; est mis sur une option apparent&eacute;e regex. Inclut un style Perl regex complet, incluant les slashes de d&eacute;but et fin ainsi que les flags (exemple : &quot;/image\.(\d+)/i&quot;)';
$lang['title_field_required_abbrev'] = 'Requis';
$lang['title_hide_errors'] = 'Cacher les erreurs&nbsp;';
$lang['title_form_displaytype'] = 'Type d&#039;affichage du formulaire';
$lang['title_hide_errors_long'] = 'Cacher aux utilisateurs l&#039;affichage des messages d&#039;erreur ou de debugage.';
$lang['title_email_template'] = 'Gabarit du mail&nbsp;';
$lang['title_maximum_size'] = 'Taille maximum pour l&#039;envoi de fichier (kilobytes)&nbsp;';
$lang['title_maximum_size_long'] = 'Cette limitation est en sus des limites php ou de celles de la configuration du serveur web';
$lang['title_file_destination'] = 'R&eacute;pertoire d&#039;enregistrerment des fichiers&nbsp;';
$lang['title_permitted_extensions'] = 'Extensions autoris&eacute;es&nbsp;';
$lang['title_permitted_extensions_long'] = 'Entrer une liste s&eacute;par&eacute;e par un caract&egrave;re autre que le point, (exemple : &quot;jpg, gif, jpeg&quot;). Les espaces seront ignor&eacute;s. Laisser vierge signifie &quot;aucune restriction&quot;.';
$lang['title_show_limitations'] = 'Afficher les restrictions ?&nbsp;';
$lang['title_show_limitations_long'] = 'Afficher les restrictions de tailles et d&#039;extensions pour le champ d&#039;upload ?';
$lang['title_form_template'] = 'Gabarit &agrave; utiliser pour afficher le formulaire&nbsp;';
$lang['title_page_x_of_y'] = 'Page %s sur %s';
$lang['title_no_advanced_options'] = 'Champ sans option avanc&eacute;e.';
$lang['title_form_unspecified'] = 'Texte &agrave; renvoyer pour les valeurs de champ non sp&eacute;cifi&eacute;es&nbsp;';
$lang['title_enable_fastadd_long'] = 'Autoriser l&#039;ajout rapide des champs de formulaire &agrave; l&#039;aide d&#039;un menu d&eacute;roulant ?';
$lang['title_enable_fastadd'] = 'Acc&egrave;s rapide au formulaire ?&nbsp;';
$lang['title_fastadd'] = 'Ajout rapide du champ';
$lang['title_enable_antispam_long'] = 'Cocher cette case limitera &agrave; 10 emails par heure la transmission des formulaires pour une m&ecirc;me adresse IP.';
$lang['title_enable_antispam'] = 'Opter pour des restrictions anti-spam ?&nbsp;';
$lang['title_show_fieldids'] = 'Montrer les ID des champs&nbsp;';
$lang['title_show_fieldids_long'] = 'Cocher cette case autorisera l&#039;affichage des ID de champs pendant l&#039;ajout ou l&#039;&eacute;dition du formulaire';
$lang['title_xml_to_upload'] = 'Importer un formulaire &agrave; partir d&#039;un fichier XML&nbsp;';
$lang['title_xml_upload_formname'] = 'Utiliser ce nom de formulaire&nbsp;';
$lang['title_import_legend'] = 'Importer un formulaire de format XML&nbsp;';
$lang['title_xml_upload_formalias'] = 'Utiliser cet alias&nbsp;';
$lang['title_html_email'] = 'G&eacute;n&eacute;rer un mail en HTML ?&nbsp;';
$lang['title_link_autopopulate'] = 'Remplir automatiquement ?&nbsp;';
$lang['title_link_autopopulate_help'] = 'Remplir automatiquement avec l&#039;URL de la page contenant le formulaire ? (Ceci r&eacute;&eacute;crira le lien de la page ci-dessous)';
$lang['title_default_link'] = 'Lien URL par d&eacute;faut&nbsp;';
$lang['title_default_link_title'] = 'Texte par d&eacute;faut du lien&nbsp;';
$lang['title_link_to_sitepage'] = 'Lien pour la page du site&nbsp;';
$lang['title_captcha_not_installed'] = 'Vous pouvez utiliser<a href="http://www.wikipedia.org/wiki/Captcha" target="_new">&quot;Captcha&quot;</a> pour prot&eacute;ger l&#039;envoi de vos formulaires en installant le module Captcha. Pour plus d&#039;informations, <a href="http://dev.cmsmadesimple.org/projects/captcha/">suivez le projet du Captcha</a>.';
$lang['title_use_captcha'] = 'Utiliser Captcha pour prot&eacute;ger l&#039;envoi de vos formulaires ?&nbsp;';
$lang['title_use_captcha_help'] = 'V&eacute;rifier ici comment prot&eacute;ger vos formulaires avec <a href="http://www.wikipedia.org/wiki/Captcha" target="_new">&quot;Captcha&quot;</a>.';
$lang['title_user_captcha'] = 'Veuillez confirmer que vous n&#039;&ecirc;tes pas un automate en recopiant les caract&egrave;res pr&eacute;sents sur l&#039;image.';
$lang['title_user_captcha_error'] = 'Echec de la v&eacute;rification Captcha&nbsp;';
$lang['wrong_captcha'] = 'Le code rentr&eacute; diff&egrave;re de l&#039;image.';
$lang['title_title_user_captcha'] = 'Texte d&#039;aide concernant Captcha&nbsp;';
$lang['title_dont_submit_unchecked'] = 'Ne pas envoyer les valeurs non-coch&eacute;es&nbsp;';
$lang['title_dont_submit_unchecked_help'] = 'Cochez ceci si vous voulez seulement que les cases coch&eacute;es retournent des valeurs.';
$lang['link_label'] = 'Label du lien&nbsp;';
$lang['link_destination'] = 'URL de destination du lien&nbsp;';
$lang['title_default_set'] = 'S&eacute;lectionn&eacute; par d&eacute;faut ?&nbsp;';
$lang['title_24_hour'] = 'Heures de 0 &agrave; 24 ? &nbsp;';
$lang['title_before_noon'] = 'AM avant midi';
$lang['title_after_noon'] = 'PM apr&egrave;s midi';
$lang['title_smarty_eval'] = 'Avec des balises Smarty dans les champs ?&nbsp;';
$lang['title_textarea_rows'] = 'Lignes (note : peut &ecirc;tre modifi&eacute; via CSS)&nbsp;';
$lang['title_textarea_cols'] = 'Colonnes (note : peut &ecirc;tre modifi&eacute; via CSS)&nbsp;';
$lang['title_form_main'] = 'Accueil - D&eacute;tails du Formulaire&nbsp;';
$lang['title_default_blank'] = 'Par d&eacute;faut &agrave; vide';
$lang['title_default_blank_help'] = 'Par d&eacute;faut &agrave; vide (d&eacute;coch&eacute; par d&eacute;faut &agrave; la date du jour)';
$lang['title_show_username'] = 'Affichage login utilisateur ?&nbsp;';
$lang['title_show_userfirstname'] = 'Affichage pr&eacute;nom utilisateur ?&nbsp;';
$lang['title_show_userlastname'] = 'Affichage nom utilisateur ?&nbsp;';
$lang['title_restrict_to_group'] = 'Liste des utilisateurs pour le groupe sp&eacute;cifi&eacute;&nbsp;';
$lang['title_encrypt_database_data'] = 'Donn&eacute;es crypt&eacute;es enregistr&eacute;es dans la base de donn&eacute;es';
$lang['title_crypt_cert'] = 'Certificat de cryptage des donn&eacute;es';
$lang['title_encryption_keyfile'] = 'Phrase secr&egrave;te ou chemin vers le fichier contenant la phrase. (Si vous utilisez OpenSSL, c&#039;est la phrase secr&egrave;te pour la cl&eacute; priv&eacute;e)';
$lang['title_encrypt_sortfields'] = 'Hacher les champs de tri ?';
$lang['title_private_key'] = 'Cl&eacute; priv&eacute;e &agrave; utiliser pour le cryptage des donn&eacute;es';
$lang['title_encrypt_sortfields_help'] = 'Ceci hache les champs de tri, mais laisse les premi&egrave;res lettres non crypt&eacute;es. Cryptographiquement, cela cr&eacute;e une vuln&eacute;rabilit&eacute;, mais reste un compromis acceptable pour une majorit&eacute; d&#039;utilisateurs entre la s&eacute;curit&eacute; et la possibilit&eacute; de trier les enregistrements. Le tri devient approximatif, mais demeure de qualit&eacute; correcte. Si vous n&#039;utilisez pas cette option, les champs de tri sont enregistr&eacute;s en texte brut.';
$lang['title_encryption_functions'] = 'Enregistrement crypt&eacute; non disponible';
$lang['title_install_crypto'] = 'Merci d&#039;installer le module OpenSSL ou mcrypt si vous souhaitez activer le cryptage de base de donn&eacute;es.';
$lang['title_install_curl'] = 'V&eacute;rifiez que vous avez les fonctions CURL activ&eacute;s dans votre installation de PHP. Voir http://www.php.net/manual/en/book.curl.php';
$lang['title_mle_version'] = 'Ex&eacute;cuter en mode MLE&nbsp;';
$lang['title_mle_version_long'] = 'Changements/support pour CMSMS Multilingue Edition. Ne cochez pas cette option si vous n&#039;utilisez pas la version MLE.';
$lang['title_ensure_cert_key_match'] = 'Assurez-vous que vous s&eacute;lectionnez la cl&eacute; priv&eacute;e qui est appropri&eacute; pour le certificat que vous utilisez pour le cryptage !';
$lang['choose_crypt'] = 'Biblioth&egrave;que de cryptage';
$lang['title_encrypt_database_long'] = 'Cochez cette option pour crypter les donn&eacute;es stock&eacute;es. Cette option rend plus difficile (mais pas impossible) l&#039;affichage de l&#039;information pour les pirates informatiques.';
$lang['choose_crypt_long'] = 'Les options ci-dessous s&#039;appliquent uniquement si vous utilisez la biblioth&egrave;que de cryptage OpenSSL';
$lang['title_crypt_lib'] = 'Biblioth&egrave;que de cryptage';
$lang['openssl'] = 'Biblioth&egrave;que OpenSSL ';
$lang['mcrypt'] = 'Biblioth&egrave;que PHP mcrypt ';
$lang['title_feu_binding'] = 'Interface Frontend User';
$lang['title_install_feu'] = 'Merci d&#039;installer le module Frontend User pour connecter un formulaire et ses donn&eacute;es &agrave; un utilisateur sp&eacute;cifique';
$lang['title_feu_bind_help'] = 'Cochez cette option pour verrouiller l&#039;acc&egrave;s des donn&eacute;es &agrave; l&#039;utilisateur connect&eacute; sur le site.';
$lang['title_encryption'] = 'Cryptage';
$lang['title_export_form_to_udt'] = 'Exporter la r&eacute;f&eacute;rence de formulaire vers un UDT en tant que $params[&#039;FORM&#039;]? (ne pas faire cela si vous utilisez print_r($params) )';
$lang['title_url_help'] = 'URL compl&egrave;te y compris le protocole et le chemin (par exemple, http://myhost.com/form_handler.cgi)';
$lang['title_url'] = 'URL du formulaire de soumission';
$lang['title_method'] = 'M&eacute;thode du formulaire';
$lang['title_maps_to'] = 'Carte du champ &quot;% s&quot; du formulaire de soumission de la variable';
$lang['title_additional'] = 'Soumission additionnelle';
$lang['title_additional_help'] = 'Tout ce qui peut &ecirc;tre ajout&eacute; &agrave; la charge de l&#039;envoi, sous forme d&#039;URL (par ex., &quot;user=steve+jobs&amp;employee_number=1)';
$lang['title_include_in_submission'] = 'Inclure dans le champ de soumission';
$lang['title_date_order'] = 'Ordre du champ composant date (pour l&#039;entr&eacute;e)';
$lang['title_data_stored_in_fbr'] = 'Les donn&eacute;es seront stock&eacute;es dans un format XML dans la table de la base [pr&eacute;fixe]_module_fb_frombrowser ';
$lang['error_has_no_fb_field'] = 'Erreur ! Soit le formulaire ne poss&egrave;de aucun arrangement de form_builder, soit il a &eacute;chou&eacute; &agrave; instancier (en raison de probl&egrave;mes de m&eacute;moire ?)';
$lang['help_date_order'] = 'Utiliser &quot;m&quot; pour mois, &quot;d&quot; pour jour, and &quot;y&quot; pour ann&eacute;e. S&eacute;parez les items par des tirets.';
$lang['restricted_to_group'] = 'Seulement pour le groupe %s&nbsp;';
$lang['title_show_to_user'] = 'Affichage utilisateur ?&nbsp;';
$lang['title_use_random_generator'] = 'Utiliser un nombre al&eacute;atoire &agrave; la place d&#039;un nombre statique';
$lang['title_numbers_to_generate'] = 'Combien de nombres &agrave; g&eacute;n&eacute;rer dans le processus';
$lang['help_leaveempty'] = 'Ce champ peut &ecirc;tre laiss&eacute; vide&nbsp;';
$lang['help_variables_for_template'] = 'Variables pour gabarit';
$lang['help_variables_for_computation'] = 'Variables autoris&eacute;es';
$lang['help_php_variable_name'] = 'Variable PHP ';
$lang['help_submission_date'] = 'Date d&#039;envoi';
$lang['help_server_name'] = 'Votre serveur';
$lang['help_sub_source_ip'] = 'Adresse IP de la personne utilisant le formulaire';
$lang['help_sub_url'] = 'URL de la page contenant le formulaire';
$lang['help_fb_version'] = 'Version de FormBuilder';
$lang['help_tab'] = 'Tabulation';
$lang['help_ignored_if_upload'] = '(Ce champ est ignor&eacute; si vous utilisez le module Uploads pour g&eacute;rer les fichiers)';
$lang['help_other_fields'] = 'Les autres noms de champs peuvent &ecirc;tre utilis&eacute;s de fa&ccedil;on interchangeable (particuli&egrave;rement utile si Smarty bloque sur les caract&egrave;res ASCII en dehors de 32-126). <br />Les autres champs seront disponibles si vous les ajouter au formulaire.';
$lang['help_array_fields'] = 'Une autre mani&egrave;re d&#039;acc&eacute;der aux valeurs de champ peut se faire via $fieldname_obj, $alias_obj, or $fld_#_obj, o&ugrave; chaque champ est un objet contenant :<br /><table>
<tr><td class=&quot;odd&quot;>name</td><td class=&quot;odd&quot;>Field Name</td></tr>
<tr><td>type</td><td>Field Type</td></tr>
<tr><td class=&quot;odd&quot;>id</td><td class=&quot;odd&quot;>Internal Field ID</td></tr>
<tr><td>value</td><td>Human-readable Value</td></tr>
<tr><td class=&quot;odd&quot;>valueArray</td><td class=&quot;odd&quot;>Array of field value(s)</td></tr></table><em>par exemple</em>, vous pouvez utiliser &quot;{$fld_1_obj->name} = {$fld_1_obj->value}';
$lang['help_date_format'] = 'Consulter le <a href="http://www.php.net/manual/fr/function.date.php" target="_blank">manuel PHP</a> pour vous aider.';
$lang['help_variable_name'] = 'Variable ';
$lang['help_form_field'] = 'Champ repr&eacute;sent&eacute;&nbsp;';
$lang['help_rtf_file_template'] = 'Sp&eacute;cifiez un fichier situ&eacute; dans le dossier FormBuilder/templates/. Ce champ est ignor&eacute; si vous utiliser un fichier de type TXT.';
$lang['help_rtf_template_type'] = 'Basic: Use the textarea below to layout the field names/values in a single block.<br />
Advanced: Specify Smarty variables in the RTF Template File as you would below, but arrange them however you like and add formatting.<br />
&nbsp;You can still use the %%HEADER%% and %%FOOTER%% sections in the RTF file.';
$lang['help_unique_file_template'] = 'For TXT, this will be immediately after the Header Template.<br />
For RTF, this will replace the %%FIELDS%% string in the template file if RTF Template Type is set to &quot;Basic&quot;.<br />
This field will be ignored if using &quot;RTF&quot; as File Type and &quot;Advanced&quot; as RTF Template Type.';
$lang['help_file_header_template'] = 'Pour les fichiers TXT, ceci sera plac&eacute; en t&ecirc;te du fichier. Pour RTF, cela remplacera la cha&icirc;ne %%HEADER%% dans le gabarit.';
$lang['help_file_footer_template'] = 'Pour les fichiers TXT, ceci sera plac&eacute; &agrave; la fin du fichier. Pour RTF, cela remplacera la cha&icirc;ne %%FOOTER%% dans le gabarit.';
$lang['link_back_to_form'] = '&laquo; Retour au Formulaire';
$lang['title_create_sample_template'] = 'Cr&eacute;er un mod&egrave;le de gabarit';
$lang['title_create_sample_html_template'] = 'Cr&eacute;er un mod&egrave;le de gabarit HTML';
$lang['title_create_sample_header_template'] = 'Cr&eacute;er un mod&egrave;le d&#039;ent&ecirc;te';
$lang['title_create_sample_footer_template'] = 'Cr&eacute;er un gabarit de pied de page ';
$lang['title_create_sample_header'] = 'Cr&eacute;er un mod&egrave;le d&#039;ent&ecirc;te';
$lang['help_tab_symbol'] = 'une tabulation';
$lang['title_file_template'] = 'Gabarit d&#039;une ligne pour les fichiers cr&eacute;es&nbsp;';
$lang['title_file_header'] = 'Gabarit du header (en-t&ecirc;te) des fichiers cr&eacute;es&nbsp;';
$lang['title_file_footer'] = 'Gabarit pour le pied de page du fichier de sorti&nbsp;';
$lang['title_rtf_file_template'] = 'Gabarit RTF &agrave; utiliser';
$lang['title_unique_file_template'] = 'Gabarit pour la sortie';
$lang['title_file_type'] = 'Choisissez un type de fichier &agrave; utiliser';
$lang['title_rtf_template_type'] = 'Choisissez un gabarit RTF';
$lang['title_confirmation_url'] = 'URL &agrave; suivre pour confirmer le formulaire&nbsp;';
$lang['title_value'] = 'Valeur (regardez dans onglets &quot;Options avanc&eacute;es&quot; si vous utilisez des balises Smarty)&nbsp;';
$lang['title_date_format'] = 'Format d&#039;affichage de la (<a href="http://www.php.net/manual/fr/function.date.php" target="_blank">date PHP standard </a>)&nbsp;';
$lang['title_use_wysiwyg'] = 'Utiliser un &eacute;diteur WYSIWYG pour la zone de texte (cot&eacute; admin seulement) ?&nbsp;';
$lang['title_submit_actions'] = 'Comportement lors de l&#039;envoi du Formulaire';
$lang['title_submit_labels'] = 'Labels des boutons de soumission';
$lang['title_sortable_field'] = 'Tri par champs #%s';
$lang['title_submit_help'] = 'Cette page vous permet de personnaliser le formulaire. Cela ne d&eacute;finit pas ce que le module Form Builder fait des donn&eacute;es r&eacute;colt&eacute;es. La destination des donn&eacute;es sera d&eacute;finie dans les champs &quot;Disposition&quot; (commen&ccedil;ant par *.... ).';
$lang['title_start_year'] = 'Ann&eacute;e de d&eacute;but&nbsp;';
$lang['title_end_year'] = 'Ann&eacute;e de fin&nbsp;';
$lang['title_default_year'] = 'Ann&eacute;e par d&eacute;faut&nbsp;';
$lang['title_default_year_help'] = '&nbsp;(Mettre -1 pour signifier que l&#039;ann&eacute;e par d&eacute;faut est l&#039;ann&eacute;e courante)';
$lang['title_submit_action'] = 'Action apr&egrave;s l&#039;envoi du formulaire&nbsp;';
$lang['title_submit_response'] = 'R&eacute;ponse &agrave; afficher&nbsp;';
$lang['title_submit_date'] = 'Date Envoy&eacute;e';
$lang['title_approval_date'] = 'Date Approuv&eacute;e (par l&#039;admin)';
$lang['title_user_approved'] = 'Date Approuv&eacute;e (par la personne qui l&#039;a soumise)';
$lang['display_text'] = 'Afficher un r&eacute;sum&eacute; du formulaire envoy&eacute;&nbsp;';
$lang['redirect_to_page'] = 'Rediriger vers une page du site';
$lang['title_submit_response_help'] = 'Ce gabarit sert &agrave; l&#039;affichage pour l&#039;utilisateur apr&egrave;s l&#039;envoi du formulaire. Ce gabarit n&#039;a aucun effet ni sur les mails, ni sur d&#039;autres formulaires - Vous placerez ces gabarits (judicieusement) dans l&#039;onglet &quot;options avanc&eacute;es&quot;.';
$lang['title_destination_page'] = 'Page de destination&nbsp;';
$lang['title_require_fieldnames'] = 'Nommage des champs requis&nbsp;';
$lang['title_require_fieldnames_long'] = 'Les champs doivent obligatoirement avoir un nom ? (case coch&eacute;e = oui)&nbsp;';
$lang['title_unique_fieldnames'] = 'Champs &agrave; nom unique requis&nbsp;';
$lang['title_unique_fieldnames_long'] = 'Les champs doivent avoir des noms diff&eacute;rents (case coch&eacute;e = oui)&nbsp;';
$lang['title_reorder_form'] = 'R&eacute;organiser les champs';
$lang['title_load_template'] = 'Charger le gabarit &nbsp;';
$lang['title_add_button_text'] = 'Ajouter un bouton texte&nbsp;';
$lang['title_del_button_text'] = 'Supprimer un bouton texte&nbsp;';
$lang['title_field_helptext'] = 'Texte d&#039;aide &agrave; afficher avec ce champ&nbsp;';
$lang['title_string_or_number_eval'] = 'Interpr&eacute;ter les variables comme &eacute;tant des nombres ou des cha&icirc;nes de caract&egrave;res&nbsp;';
$lang['title_order'] = 'Ordre d&#039;interpr&eacute;tation&nbsp;';
$lang['title_order_help'] = 'Si plus d&#039;un champ de calcul existe, ils seront calcul&eacute; du plus petit au plus grand';
$lang['title_string_unspaced'] = 'Chine (pas d&#039;espaces entre les champs) ?';
$lang['title_compute_value'] = 'Valeur de calcul&nbsp;';
$lang['title_compute'] = 'Utilisation de PHP';
$lang['title_string'] = 'Cha&icirc;nes de caract&egrave;res';
$lang['title_numeric'] = 'Numerique';
$lang['title_inline_form'] = 'Montrer le formulaire en ligne ?&nbsp;';
$lang['title_inline_form_help'] = 'Coch&eacute; signifie que le r&eacute;sultat de la soumission du formulaire remplace la balise {cms_module}, non-coch&eacute; remplace la balise {content}.';
$lang['title_field_default_value'] = 'Valeur par d&eacute;faut pour le champ&nbsp;';
$lang['title_clear_default'] = 'Effacer la valeur par d&eacute;faut par un clic ?';
$lang['title_clear_default_help'] = 'Cocher cette case pour effacer la valeur par d&eacute;faut quand l&#039;utilisateur cliquera ce champ. Puisque cela utilise la comparaison de cha&icirc;ne en javascript, cela &eacute;chouera si vous ins&eacute;rez des balises de citation simples dans votre texte par d&eacute;faut. V&eacute;rifier les caract&egrave;res utilis&eacute;s pour &eacute;viter les erreurs.';
$lang['title_remove_file_from_server'] = 'Supprimer les fichiers upload&eacute;s depuis le serveur apr&eacute;s ex&eacute;cution (dispositions email)&nbsp;';
$lang['title_field_javascript'] = 'Javascript pour le champ&nbsp;';
$lang['title_field_javascript_long'] = 'Mettre le code Javascript, inclut les &eacute;v&egrave;nements, ex : onclick=&quot;yourfn()&quot;';
$lang['title_submit_javascript'] = 'Formulaire de soumission Javascript&nbsp;';
$lang['title_submit_javascript_long'] = 'Mettre le code Javascript, en incluant l&#039;&eacute;v&egrave;nement que vous voulez pi&eacute;ger, ex : onclick=&quot;yourfn()&quot;.<br /> Ne fonctionnera probablement pas bien si vous utilisez l&#039;option de &quot;script s&eacute;curit&eacute;&quot; ci-dessus.';
$lang['email_from_addr_help'] = 'Ne vous contentez pas de choisir une adresse al&eacute;atoire ici -- Beaucoup de fournisseurs <br /> ne distribueront pas le courrier si vous utilisez un nom de domaine diff&eacute;rent que votre <br /> nom d&#039;h&ocirc;te (par exemple, utilisez quelque chose comme nom@%s)';
$lang['title_switch_advanced'] = 'Besoin de plus de types de champs ? ';
$lang['title_switch_basic'] = 'Trop de types de champ confus ? ';
$lang['title_switch_advanced_link'] = 'Passer en mode avanc&eacute;';
$lang['title_switch_basic_link'] = 'Passer en mode simple';
$lang['title_file_root'] = 'Dossier dans lequel le fichier sera sauv&eacute;&nbsp;';
$lang['title_file_root_help'] = 'Ce doit &ecirc;tre un dossier de votre serveur Web avec des permissions d&#039;&eacute;criture<br />Passez-le en CHMOD 777 si vous avez des probl&egrave;mes ou doutes.<br />De plus, v&eacute;rifiez que vous n&#039;avez pas de restriction de r&eacute;pertoire PHP.';
$lang['title_newline_replacement'] = 'Nouvelle ligne/Retour &agrave; la ligne en remplacement de caract&egrave;res&nbsp;';
$lang['title_newline_replacement_help'] = 'Laisser vierge la ligne pour permettre une Nouvelle ligne/Retour &agrave; la ligne';
$lang['title_send_usercopy'] = 'Envoyer une copie de la soumission &agrave; l&#039;utilisateur ?&nbsp;';
$lang['title_send_usercopy_label'] = 'Etiquette pour case &agrave; cocher (si choix utilisateur)&nbsp;';
$lang['title_send_me_a_copy'] = 'M&#039;envoyer une copie du formulaire';
$lang['title_allow_subject_override'] = 'Autoriser que l&#039;objet soit annul&eacute; ?';
$lang['title_allow_subject_override_long'] = 'Autoriser les champs de type &quot;Sujet de l&#039;e-mail&quot; &agrave; l&#039;emporter sur le sujet sp&eacute;cifi&eacute; dans le menu d&eacute;roulant.';
$lang['title_display_length'] = 'Affichage de la longueur';
$lang['title_minimum_length'] = 'Longueur minimum pour la r&eacute;ponse';
$lang['title_hide'] = 'Masquer l&#039;entr&eacute;e';
$lang['title_hide_help'] = 'Afficher les caract&egrave;res lorsque l&#039;utilisateur entre un mot de passe ?';
$lang['password_does_not_match'] = 'Le mot de passe ne correspond pas %s';
$lang['back_top'] = 'Retour &agrave; la page principale FormBuilder';
$lang['title_headers_to_modify'] = 'Quelles ent&ecirc;tes de messagerie devraient utiliser cette entr&eacute;e ?';
$lang['title_blank_invalid'] = 'N&#039;acceptez pas d&#039;espace vide comme r&eacute;ponse valide&nbsp;';
$lang['title_blank_invalid_long'] = 'Si un champ est requis, cocher ceci obligera l&#039;utilisateur &agrave; remplir avec des caract&egrave;res alphanum&eacute;riques, pas juste des espaces ';
$lang['title_must_save_order'] = 'Vous devez cliquer sur un des boutons &laquo;Sauvegarder&raquo; pour valider le nouvel ordre des champs.';
$lang['title_html5'] = 'Utiliser HTML5 au lieu de Javascript';
$lang['title_email_cc_address'] = 'Adresse(s) auxquelles envoyer en Copie Carbone (CC). Utilisez des virgules pour s&eacute;parer les adresses.';
$lang['title_use_bcc'] = 'Utiliser la Copie Carbone Invisible (CCI) au lieu de la Copie Carbone (CC)';
$lang['title_send_using'] = 'Adressage de mail';
$lang['title_field_to_modify'] = 'Champ email pour ajouter l&#039;adresse CC';
$lang['title_modifies'] = 'Ajouter CC &agrave; &quot;%s&quot;';
$lang['bcc_field'] = 'Destinataires &quot;CCI&quot;';
$lang['cc_field'] = 'Destinataires &quot;CC&quot;';
$lang['to_field'] = 'Normal (&quot;To&quot; recipients)';
$lang['bcc'] = 'CCI';
$lang['cc'] = 'CC';
$lang['error_CompanyDirectory_module_not_available'] = 'Le module Company Directory n&#039;est pas disponible !';
$lang['option_never'] = 'Jamais';
$lang['option_user_choice'] = 'Donne un choix &agrave; l&#039;utilisateur (case &agrave; cocher)';
$lang['option_always'] = 'Toujours';
$lang['option_from'] = 'Adresse email pour &quot;From&quot; (De)';
$lang['option_reply'] = 'Adresse email pour &quot;Reply-To&quot; (R&eacute;pondre &agrave;)';
$lang['option_both'] = 'Adresses email pour &agrave; la fois &quot;From&quot; et &quot;Reply-To&quot;';
$lang['option_dropdown'] = 'list-box de s&eacute;lection';
$lang['option_selectlist_single'] = 'Liste simple';
$lang['option_selectlist_multiple'] = 'Liste multiple';
$lang['option_radiogroup'] = 'Groupe de boutons radio';
$lang['title_company_field_note'] = 'Note : la sortie formulaire sera<br/>&quot;company name&quot;=>&quot;value&quot;';
$lang['title_pick_categories'] = 'Choisissez une cat&eacute;gorie (multiple)';
$lang['title_pick_fielddef'] = 'Donne un champ de d&eacute;finition de la valeur (unique) <em>option</em>';
$lang['title_choose_user_input'] = 'Choisir une entr&eacute;e utilisateur ';
$lang['title_see_also_udt'] = '(Vous pouvez &eacute;galement naviguer dans l&#039;onglet Formulaire de soumission si vous souhaitez d&eacute;finir une balise utilisateur pour le formulaire de validation)';
$lang['title_year_end_message'] = 'Fin de l&#039;ann&eacute;e';
$lang['title_field_logic'] = 'Donn&eacute;es ou balises Smarty qui doivent &ecirc;tre envoy&eacute;s avec ce champ&nbsp;';
$lang['title_field_logic_long'] = 'Donn&eacute;es Smarty, javascript, ou toute autre donn&eacute;e que vous voulez envoyer avec ce champ.<br />S&#039;ex&eacute;cute via le compileur smarty, utiliser les balises {literal}{/literal} avec < script >< /script >';
$lang['title_field_includelabels'] = 'Inclut les intitul&eacute;s';
$lang['title_field_includelabels_help'] = 'Activer ceci inclut les intitul&eacute;s &agrave; appara&icirc;tre. Exemple - label: value,label2: value2';
$lang['title_field_siblings'] = 'Lie ce champ &agrave; son parent';
$lang['title_field_siblings_help'] = 'Menu d&eacute;roulant qui liste tous les parents de ce champ et vous permet de lier ce champ avec un de ses parents. Rend possible de contr&ocirc;ler ce champ avec les contr&ocirc;les du parent s&eacute;lectionn&eacute;.';
$lang['title_field_hidebuttons'] = 'Cache les boutons de contr&ocirc;le';
$lang['title_field_hidebuttons_help'] = 'Cache les boutons de contr&ocirc;le de ce champ sur l&#039;interface publique';
$lang['title_note'] = 'Note&nbsp;';
$lang['title_changing_triggers_reindex'] = 'Modification de l&#039;un des champs ci-dessus d&eacute;clenchera une r&eacute;-indexation de *tous* les enregistrements, cela pourrait prendre un certain temps.';
$lang['illegal_file'] = 'Tentative de t&eacute;l&eacute;chargement ill&eacute;gal de fichiers de type (%s) depuis %s';
$lang['title_searchable'] = 'Faire des enregistrements accessibles pour le module de recherche';
$lang['title_searchable_help'] = 'En cochant, cela rendra toutes les donn&eacute;es accessibles dans le module de recherche. NE PAS utiliser cette option si vous cryptez vos donn&eacute;es -- Les informations seront soumises &agrave; la recherche si vous cryptez ou non !';
$lang['uploaded_outside_webroot'] = '%s (hors de la racine du site web)';
$lang['title_fbr_edit'] = '&Eacute;ditable dans l&#039;administration du module FormBrowser ?';
$lang['title_active_only'] = 'Inclure seulement les utilisateurs actifs ?';
$lang['error_usertag_disposition'] = 'La balise utilisateur a retourn&eacute; une erreur';
$lang['error_usertag'] = 'la balise utilisateur %s returne une erreur.';
$lang['error_cataloger_module_not_available'] = '<strong>Le module Cataloger ne semble pas &ecirc;tre install&eacute;/actif.</strong>';
$lang['warning'] = 'ATTENTION !';
$lang['default_template'] = 'Gabarit par d&eacute;faut';
$lang['table_left_template'] = 'Gabarit tableau, Titres &agrave; gauche';
$lang['table_top_template'] = 'Gabarit tableau, Titres en haut';
$lang['form_template_name'] = 'Gabarit venant de %s';
$lang['template_are_you_sure'] = '\u00CAtes-vous s\u00FBr de vouloir &eacute;crire par dessus votre gabarit avec le gabarit s&eacute;lectionn&eacute; ? (m\u00EAme si vous dites OK, vous devrez quand m\u00EAme sauvegarder le changement)';
$lang['title_bad_function'] = 'Erreur de calcul &quot;%s&quot;.';
$lang['no_referrer_info'] = 'Pas d&#039;information HTTP_REFERER disponible (probablement d&ucirc; &agrave; l&#039;usage de validation d&#039;Email utilisateur)';
$lang['validation_param_error'] = 'Erreur du param&egrave;tre de validation. V&eacute;rifiez que vous avez recopi&eacute; correctement l&#039;URL de l&#039;email !';
$lang['validation_response_error'] = 'Erreur de r&eacute;ponse de la validation. V&eacute;rifiez que vous avez recopi&eacute; correctement l&#039;URL de l&#039;email !';
$lang['validation_no_field_error'] = 'Erreur de r&eacute;ponse de la validation. Aucun champ de validation d&#039;email dans ce formulaire !';
$lang['upgrade03to04'] = 'Le gabarit de formulaire a &eacute;t&eacute; mis &agrave; jour automatiquement de la version 0.3 vers la version 0.4. Il se peut que vous ayez &agrave; faire certaines corrections. Si vous utilisez le formulaire par d&eacute;faut, remplacez simplement ce gabarit par &quot;default&quot; en utilisant le menu d&eacute;roulant ci-dessus.';
$lang['admindesc'] = 'Ajout, &eacute;dition et gestion de formulaires interactifs';
$lang['must_specify_one_admin'] = 'Doit sp&eacute;cifier un administrateur';
$lang['operators_help'] = 'Si vous utilisez une &eacute;valuation de cha&icirc;ne de caract&egrave;res, la seule op&eacute;ration possible est la concat&eacute;nation (+), alors que si vous utilisez une &eacute;valuation num&eacute;rique, vous avez les symboles de base (, +, -, *, /, ). Si vous utilisez l&#039;&eacute;valuation par le PHP, vous pouvez 
utiliser n&#039;importe quelle fonction vous voulez, mais vous avez besoin de citer des choses (la substitution se produit avant l&#039;&eacute;valuation), par exemple, substr (&#039;$fld_22&#039;,0,2).&#039;$fld_23&#039;.';
$lang['help_module_interface'] = 'Utiliser le module d&#039;interface';
$lang['help_module_interface_long'] = '<b>Ce champ est utilis&eacute; comme un pont vers les autres modules !</b>
Utilisez-le en cr&eacute;ant vos &eacute;l&eacute;ments de formulaire dans les gabarits de(s) l&#039;autre(s) module(s) que vous voulez incorporer, et utilisez <strong>{$FBid}</strong> pour le lier en retour vers FormBuilder. Par exemple, pour inclure le formulaire d&#039;options bas&eacute; sur le module Products, cr&eacute;ez le gabarit suivant dans Products :<br/>
<pre>
{foreach from=$items item=entry}
	{assign var=MData value=&#039;&#039;}
	{assign var=Cd value=&#039;&#039;}
		{foreach from=$FBvalue item=MData}
			{assign var=MData value=&#039;::&#039;|explode:$MData}
			{if $MData[1]==$entry->id}
				{assign var=Cd value=&#039; checked=&quot;checked&quot;&#039;}
			{/if}
		{/foreach}
	<div class=&quot;ProductDirectoryItem&quot;>
		<input type=&quot;checkbox&quot; value=&quot;{$entry->price}::{$entry->id}&quot; name=&quot;{$FBid}[]&quot; {$Cd} />{$entry->product_name} ({$entry->weight}{$weight_units}) &pound;{$entry->price}    
	</div>
{/foreach}
</pre>
<br/>
o&ugrave; vous pouvez mettre dans l&#039;entr&eacute;e ci-dessous quelque chose comme <strong>{Products category=&quot;cat&quot; summarytemplate=&quot;Your_FB_template&quot;}</strong>';
$lang['title_add_tag'] = 'Ajouter votre balise';
$lang['date_january'] = 'Janvier';
$lang['date_february'] = 'F&eacute;vrier';
$lang['date_march'] = 'Mars';
$lang['date_april'] = 'Avril';
$lang['date_may'] = 'Mai';
$lang['date_june'] = 'Juin';
$lang['date_july'] = 'Juillet';
$lang['date_august'] = 'Ao&ucirc;t';
$lang['date_september'] = 'Septembre';
$lang['date_october'] = 'Octobre';
$lang['date_november'] = 'Novembre';
$lang['date_december'] = 'D&eacute;cembre';
$lang['AF'] = 'Afghanistan ';
$lang['AX'] = 'Aland Islands ';
$lang['AL'] = 'Albanie ';
$lang['DZ'] = 'Alg&eacute;rie ';
$lang['AS'] = 'American Samoa ';
$lang['AD'] = 'Andorre ';
$lang['AO'] = 'Angola ';
$lang['AI'] = 'Anguilla ';
$lang['AQ'] = 'Antarctique';
$lang['AG'] = 'Antigua et Barbuda ';
$lang['AR'] = 'Argentine';
$lang['AM'] = 'Arm&eacute;nie ';
$lang['AW'] = 'Aruba ';
$lang['AU'] = 'Australie ';
$lang['AT'] = 'Autriche ';
$lang['AZ'] = 'Azerbaidjan ';
$lang['BS'] = 'Bahamas ';
$lang['BH'] = 'Bahrain ';
$lang['BB'] = 'Barbades';
$lang['BD'] = 'Bangladesh ';
$lang['BY'] = 'Belarus ';
$lang['BE'] = 'Belgique ';
$lang['BZ'] = 'Belize ';
$lang['BJ'] = 'B&eacute;nin ';
$lang['BM'] = 'Bermudes ';
$lang['BT'] = 'Boutan ';
$lang['BW'] = 'Botswana ';
$lang['BO'] = 'Bolivie ';
$lang['BA'] = 'Bosnie et Herz&eacute;govine ';
$lang['BV'] = 'Ile Bouvet';
$lang['BR'] = 'Br&eacute;sil';
$lang['IO'] = 'British Indian Ocean Territory ';
$lang['BN'] = 'Brunei Darussalam ';
$lang['BG'] = 'Bulgarie';
$lang['BF'] = 'Burkina Faso ';
$lang['BI'] = 'Burundi ';
$lang['KH'] = 'Cambodge ';
$lang['CM'] = 'Cameroon ';
$lang['CA'] = 'Canada ';
$lang['CV'] = 'Cape Verde ';
$lang['KY'] = 'Iles Cayman ';
$lang['CF'] = 'R&eacute;publique Centrafricaine';
$lang['TD'] = 'Tchad ';
$lang['CL'] = 'Chili ';
$lang['CN'] = 'Chine';
$lang['CX'] = 'Ile Christmas';
$lang['CC'] = 'Cocos (Keeling) Islands ';
$lang['CO'] = 'Colombia ';
$lang['KM'] = 'Comoros ';
$lang['CG'] = 'Congo ';
$lang['CD'] = 'Congo,  R&eacute;publique D&eacute;mocratique ';
$lang['CK'] = 'Cook Islands ';
$lang['CR'] = 'Costa Rica ';
$lang['CI'] = 'Ivoire (C&ocirc;te d&#039;ivoire) ';
$lang['HR'] = 'Croatie (Hrvatska) ';
$lang['CU'] = 'Cuba ';
$lang['CY'] = 'Chypre';
$lang['CZ'] = 'R&eacute;publique Tch&egrave;que ';
$lang['DK'] = 'Danemark ';
$lang['DJ'] = 'Djibouti ';
$lang['DM'] = 'Dominique ';
$lang['DO'] = 'R&eacute;publique Dominicaine';
$lang['TP'] = 'Timor Oriental ';
$lang['EC'] = 'Equateur ';
$lang['EG'] = 'Egypte ';
$lang['SV'] = 'El Salvador ';
$lang['GQ'] = 'Guin&eacute;e Equatorial';
$lang['ER'] = 'Erithr&eacute;e';
$lang['EE'] = 'Estonie ';
$lang['ET'] = 'Ethiopie ';
$lang['FK'] = 'Iles Malouines (Malvinas) ';
$lang['FO'] = 'Iles Fero&euml;';
$lang['FJ'] = 'Fiji ';
$lang['FI'] = 'Finlande ';
$lang['FR'] = 'France ';
$lang['FX'] = 'France M&eacute;tropolitaine ';
$lang['GF'] = 'Guernesey ';
$lang['PF'] = 'Polyn&eacute;sie Fran&ccedil;aise';
$lang['TF'] = 'French Southern Territories ';
$lang['MK'] = 'F.Y.R.O.M. (Macedonia) ';
$lang['GA'] = 'Gabon ';
$lang['GM'] = 'Gambie ';
$lang['GE'] = 'G&eacute;orgie ';
$lang['DE'] = 'Allemagne';
$lang['GH'] = 'Ghana ';
$lang['GI'] = 'Gibraltar ';
$lang['GB'] = 'Royaume-Uni (UK) ';
$lang['GR'] = 'Gr&egrave;ce ';
$lang['GL'] = 'Gro&euml;nland ';
$lang['GD'] = 'Grenade ';
$lang['GP'] = 'Guadeloupe ';
$lang['GU'] = 'Guam ';
$lang['GT'] = 'Guatemala ';
$lang['GN'] = 'Guin&eacute;e ';
$lang['GW'] = 'Guin&eacute;e-Bissau ';
$lang['GY'] = 'Guyane ';
$lang['HT'] = 'Ha&iuml;ti ';
$lang['HM'] = 'Heard and McDonald Islands ';
$lang['HN'] = 'Honduras ';
$lang['HK'] = 'Hong Kong ';
$lang['HU'] = 'Hongrie ';
$lang['IS'] = 'Islande';
$lang['IN'] = 'Inde ';
$lang['ID'] = 'Indon&eacute;sie ';
$lang['IR'] = 'Iran ';
$lang['IQ'] = 'Irak';
$lang['IE'] = 'Irlande ';
$lang['IL'] = 'Isra&euml;l ';
$lang['IM'] = 'Ile de Man ';
$lang['IT'] = 'Italie ';
$lang['JE'] = 'Jersey ';
$lang['JM'] = 'Jama&iuml;que';
$lang['JP'] = 'Japon ';
$lang['JO'] = 'Jordanie';
$lang['KZ'] = 'Kazakhstan ';
$lang['KE'] = 'Kenya ';
$lang['KI'] = 'Kiribati ';
$lang['KP'] = 'Cor&eacute;e (du Nord) ';
$lang['KR'] = 'Cor&eacute;e (du Sud) ';
$lang['KW'] = 'Kowe&iuml;t';
$lang['KG'] = 'Kyrgyzstan ';
$lang['LA'] = 'Laos ';
$lang['LV'] = 'Latvie ';
$lang['LB'] = 'Liban ';
$lang['LI'] = 'Liechtenstein ';
$lang['LR'] = 'Lib&eacute;ria ';
$lang['LY'] = 'Lybie';
$lang['LS'] = 'Lesotho ';
$lang['LT'] = 'Lithuanie ';
$lang['LU'] = 'Luxembourg ';
$lang['MO'] = 'Macao';
$lang['MG'] = 'Madagascar ';
$lang['MW'] = 'Malawi ';
$lang['MY'] = 'Malaysie ';
$lang['MV'] = 'Maldives ';
$lang['ML'] = 'Mali ';
$lang['MT'] = 'Malte ';
$lang['MH'] = 'Iles Marshall';
$lang['MQ'] = 'Martinique ';
$lang['MR'] = 'Mauritanie ';
$lang['MU'] = 'Ile Maurice';
$lang['YT'] = 'Mayotte ';
$lang['MX'] = 'Mexique';
$lang['FM'] = 'Micron&eacute;sie';
$lang['MC'] = 'Monaco ';
$lang['MD'] = 'Moldavie ';
$lang['MA'] = 'Maroc ';
$lang['MN'] = 'Mongolie ';
$lang['MS'] = 'Montserrat ';
$lang['MZ'] = 'Mozambique ';
$lang['MM'] = 'Myanmar ';
$lang['NA'] = 'Namibie ';
$lang['NR'] = 'Nauru ';
$lang['NP'] = 'N&eacute;pal ';
$lang['NL'] = 'Pays Bas';
$lang['AN'] = 'Netherlands Antilles ';
$lang['NT'] = 'Neutral Zone ';
$lang['NC'] = 'Nouvelle Cal&eacute;donie ';
$lang['NZ'] = 'Nouvelle Z&eacute;lande (Aotearoa) ';
$lang['NI'] = 'Nicaragua ';
$lang['NE'] = 'Niger ';
$lang['NG'] = 'Nig&eacute;ria ';
$lang['NU'] = 'Niue ';
$lang['NF'] = 'Norfolk Island ';
$lang['MP'] = 'Northern Mariana Islands ';
$lang['NO'] = 'Norv&egrave;ge ';
$lang['OM'] = 'Oman ';
$lang['PK'] = 'Pakistan ';
$lang['PW'] = 'Palau ';
$lang['PS'] = 'Palestinian Territory ';
$lang['PA'] = 'Panama ';
$lang['PG'] = 'Papouasie Nouvelle Guin&eacute;e';
$lang['PY'] = 'Paraguay ';
$lang['PE'] = 'P&eacute;rou ';
$lang['PH'] = 'Philippines ';
$lang['PN'] = 'Pitcairn ';
$lang['PL'] = 'Pologne';
$lang['PT'] = 'Portugal ';
$lang['PR'] = 'Porto Rico ';
$lang['QA'] = 'Qatar ';
$lang['RE'] = 'R&eacute;union ';
$lang['RO'] = 'Roumanie ';
$lang['RU'] = 'F&eacute;d&eacute;ration de Russie';
$lang['RW'] = 'Rwanda ';
$lang['GS'] = 'S. Georgia and S. Sandwich Isls. ';
$lang['KN'] = 'Saint Kitts et Nevis ';
$lang['LC'] = 'Saint Lucie ';
$lang['VC'] = 'Saint Vincent et les Grenadines ';
$lang['WS'] = 'Samoa ';
$lang['SM'] = 'San Marino ';
$lang['ST'] = 'Sao Tome et Principe ';
$lang['SA'] = 'Arabie Saoudite';
$lang['SN'] = 'S&eacute;n&eacute;gal ';
$lang['SC'] = 'Seychelles ';
$lang['SL'] = 'Sierra Leone ';
$lang['SG'] = 'Singapore ';
$lang['SI'] = 'Slov&eacute;nie ';
$lang['SK'] = 'Slovak Republic ';
$lang['SB'] = 'Solomon Islands ';
$lang['SO'] = 'Somalie ';
$lang['ZA'] = 'South Africa ';
$lang['ES'] = 'Spain ';
$lang['LK'] = 'Sri Lanka ';
$lang['SH'] = 'St-H&eacute;l&egrave;ne ';
$lang['PM'] = 'St-Pierre et Miquelon  ';
$lang['SD'] = 'Soudan ';
$lang['SR'] = 'Suriname ';
$lang['SJ'] = 'Svalbard &amp; Jan Mayen Islands ';
$lang['SZ'] = 'Swaziland ';
$lang['SE'] = 'Su&egrave;de ';
$lang['CH'] = 'Switzerland ';
$lang['SY'] = 'Syrie ';
$lang['TW'] = 'Ta&iuml;wan ';
$lang['TJ'] = 'Tajikistan ';
$lang['TZ'] = 'Tanzanie ';
$lang['TH'] = 'Tha&iuml;lande ';
$lang['TG'] = 'Togo ';
$lang['TK'] = 'Tokelau ';
$lang['TO'] = 'Tonga ';
$lang['TT'] = 'Trinidad et Tobago ';
$lang['TN'] = 'Tunisie ';
$lang['TR'] = 'Turquie';
$lang['TM'] = 'Turkmenistan ';
$lang['TC'] = 'Turks et Caicos';
$lang['TV'] = 'Tuvalu ';
$lang['UG'] = 'Uganda ';
$lang['UA'] = 'Ukraine ';
$lang['AE'] = ' United Arab Emirates';
$lang['UK'] = 'Royaume Uni';
$lang['US'] = 'Etats-Unis';
$lang['UM'] = 'US Minor Outlying Islands ';
$lang['UY'] = 'Uruguay ';
$lang['UZ'] = 'Uzbekistan ';
$lang['VU'] = 'Vanuatu ';
$lang['VA'] = 'Vatican City State (Holy See) ';
$lang['VE'] = 'Venezuela ';
$lang['VN'] = 'Viet Nam ';
$lang['VG'] = 'Virgin Islands (British) ';
$lang['VI'] = 'Virgin Islands (U.S.) ';
$lang['WF'] = 'Wallis and Futuna Islands ';
$lang['EH'] = 'Western Sahara ';
$lang['YE'] = 'Yemen ';
$lang['YU'] = 'Yugoslavia ';
$lang['ZM'] = 'Zambia ';
$lang['ZW'] = 'Zimbabwe ';
$lang['submission_error'] = 'D&eacute;sol&eacute; ! Une erreur a emp&ecirc;ch&eacute; la transmission du formulaire.';
$lang['submit_error'] = 'Erreur de soumission FormBuilder : %s';
$lang['uploads_error'] = 'Erreur en soumettant un fichier au module d&#039;upload : %s';
$lang['nouploads_error'] = 'Module d&#039;upload introuvable';
$lang['upload_attach_error'] = 'Erreur d&#039;Upload/Attachement sur le fichier %s (tmp_name : %s, de type %s)';
$lang['submission_error_file_lock'] = 'Erreur. Impossible d&#039;obtenir le blocage du fichier.';
$lang['unchecked_by_default'] = 'Par d&eacute;faut : d&eacute;coch&eacute;';
$lang['checked_by_default'] = 'Par d&eacute;faut : coch&eacute;';
$lang['email_default_template'] = 'Soumission par FormBuilder';
$lang['email_template_not_set'] = '<br/>Gabarit du mail pas encore d&eacute;fini !';
$lang['missing_cms_mailer'] = 'FormBuilder : impossible de trouver le module CMSMailer requis !';
$lang['user_approved_submission'] = 'Utilisateur approuvant la soumission %s de %s';
$lang['event_info_OnFormBuilderFormSubmit'] = 'Ev&eacute;nement d&eacute;clench&eacute; lorsqu&#039;un formulaire FormBuilder est envoy&eacute;';
$lang['event_info_OnFormBuilderFormSubmitError'] = 'Ev&eacute;nement d&eacute;clench&eacute; s&#039;il y a une erreur lorsqu&#039;un formulaire FormBuilder est envoy&eacute;';
$lang['event_info_OnFormBuilderFormDisplay'] = 'Ev&eacute;nement d&eacute;clench&eacute; lorsqu&#039;un formulaire FormBuilder est affich&eacute;';
$lang['event_help_OnFormBuilderFormSubmit'] = '<p>Ev&eacute;nement d&eacute;clench&eacute; lorsqu&#039;un formulaire FormBuilder est envoy&eacute;.</p>
<h4>Param&egrave;tres</h4>
<ul>
<li><em>form_name</em> - Le nom du formulaire (string)</li>
<li><em>form_id</em> - L&#039;id interne du formulaire (int)</li>
<li><em>value_<name></em> - Fournit une valeur par d&eacute;faut &agrave; un champ avec le nom pr&eacute;cis&eacute;.</li>
</ul> ';
$lang['event_help_OnFormBuilderFormSubmitError'] = '<p>Ev&eacute;nement d&eacute;clench&eacute; s&#039;il y a une erreur lorsqu&#039;un formulaire FormBuilder est envoy&eacute;</p>
<h4>Param&egrave;tres</h4>
<ul>
<li><em>form_name</em> - Le nom du formulaire (string)</li>
<li><em>form_id</em> - L&#039;id interne du formulaire (int)</li>
<li><em>error</em> - Une liste de toutes les erreurs connues (string)</li>
</ul> ';
$lang['event_help_OnFormBuilderFormDisplay'] = '<p>Ev&eacute;nement d&eacute;clench&eacute; lorsqu&#039;un formulaire FormBuilder est affich&eacute;</p>
<h4>Param&egrave;tres</h4>
<ul>
<li><em>form_name</em> - Le nom du formulaire (string)</li>
<li><em>form_id</em> - L&#039;id interne du formulaire (int)</li>
</ul> ';
$lang['formbuilder_params_response_id'] = 'ID. de la r&eacute;ponse utilis&eacute;e par le module FormBrowser';
$lang['formbuilder_params_passed_from_tag'] = 'Valeurs du champ par d&eacute;faut; voir le module d&#039;aide';
$lang['formbuilder_params_field_id'] = 'ID du champ pour les op&eacute;rations internes';
$lang['formbuilder_params_form_name'] = 'Nom du formulaire';
$lang['formbuilder_params_form_id'] = 'ID du formulaire pour les op&eacute;rations internes';
$lang['formbuilder_params_general'] = 'Param&egrave;tres g&eacute;n&eacute;raux pour les op&eacute;rations internes';
$lang['template_variable_help'] = '<h3>Variables du Gabarit de Formulaire</h3>
<p>Vous pouvez l&#039;&eacute;diter pour que la pr&eacute;sentation de votre formulaire soit conforme &agrave; vos souhaits.
   Pour que le formulaire fonctionne, vous devrez toujours inclure les tags {$fb_hidden} et {$submit}.</p>

<p>Vous pouvez acc&eacute;der &agrave; vos champs de formulaire en utilisant soit l&#039;ordre $fields soit directement par leurs noms (e.g., {$myfield->input} )</p>


<p>Voici les diff&eacute;rentes valeurs applicables aux champs :</p>
<table>
<tr><th>Champ</th><th>Valeur</th></tr>
<tr><td>field->display</td><td>1 pour afficher le champ, sinon 0</td></tr>
<tr><td>field->required</td><td>1 si le champ est requis, sinon 0</td></tr>
<tr><td>field->required_symbol</td><td>Le symbole signalant les champs obligatoires</td></tr>
<tr><td>field->css_class</td><td>La classe CSS de ce champ</td></tr>
<tr><td>field->valid</td><td>1 si le champ &eacute;t&eacute; valide, sinon 0</td></tr>
<tr><td>field->error</td><td>Texte pour les probl&egrave;mes de validation, au cas o&ugrave; le champ ne serait pas valid&eacute;</td></tr>
<tr><td>field->hide_name</td><td>1 si le nom du champs doit rester cach&eacute;, sinon 0</td></tr>
<tr><td>field->has_label</td><td>1 si le type de champ a un label</td></tr>
<tr><td>field->needs_div</td><td>1 si le champ doit &ecirc;tre int&eacute;gr&eacute; dans un DIV (ou dans une ligne de tableau, si c&#039;est votre choix)</td></tr>
<tr><td>field->name</td><td>Le nom du champ</td></tr>
<tr><td>field->helptext</td><td>Le champ de texte d&#039;aide</td></tr>
<tr><td>field->input</td><td>La valeur de contr&ocirc;le du champ (ex. : la valeur du champ)</td></tr>
<tr><td>field->op</td><td>un bouton de contr&ocirc;le associ&eacute; au champ si c&#039;est possible (ex. : le bouton supprimer pour un champ texte)</td></tr>
<tr><td>field->input_id</td><td>l&#039; ID du champ (utile pour un label for=&quot;foo&quot;>)</td></tr>
<tr><td>field->alias</td><td>l&#039;alias sp&eacute;cifi&eacute; pour ce champ</td></tr>
<tr><td>field->id</td><td>l&#039;id interne / opaque que FormBuilder utilise pour ce champ</td></tr>
<tr><td>field->type</td><td>le type de donn&eacute;es du champ</td></tr>
                                
<tr><td>field->multiple_parts</td><td>1 si le champ->input est une collection de contr&ocirc;les</td></tr>
<tr><td>field->label_parts</td><td>1 si la collection de contr&ocirc;les a des labels s&eacute;par&eacute;s pour chaque contr&ocirc;le</td></tr>
</table>

<p>Dans le cas d&#039;un formulaire &agrave; plusieurs pages, vous aurez aussi acc&egrave;s &agrave; la valeur des champs pr&eacute;c&eacute;dents. Ils sont dans $previous array, ou accessibles par leurs noms (ex. : &amp;#123;$myfield->value} ).
Vous pouvez aussi utiliser Static Text fields, ce qui constitue une bonne fa&ccedil;on de personnaliser vos formulaires !</p>

<p>Dans certains cas, field->input est en fait un groupe d&#039;objets plut&ocirc;t qu&#039;une entr&eacute;e. &Ccedil;a arrive, par exemple, dans CheckBoxGroups ou RadioButtonGroups. Dans ce cas, vous pouvez les r&eacute;p&eacute;ter avec field->input->name et field->input->inputs.</p>
    
<p>Voici les variables smarty compl&eacute;mentaires que vous pouvez utiliser :</p>
<table>
<tr><th>Variable</th><th>Valeur</th></tr>
<tr><td>total_pages</td><td>nombre de pages pour un formulaire multi-pages</td></tr>
<tr><td>this_page</td><td>num&eacute;ro de la page courrante pour un formulaire multi-pages</td></tr>
<tr><td>title_page_x_of_y</td><td>affiche &quot;page x de y&quot; pour un formulaire multi-pages</td></tr>
<tr><td>css_class</td><td>La classe CSS pour le formulaire</td></tr>
<tr><td>form_name</td><td>Nom du formulaire</td></tr>
<tr><td>form_id</td><td>ID de la base de donn&eacute;es du formulaire</td></tr>

<tr><td>in_formbrowser</td><td>1 Si le formulaire est affich&eacute; &agrave; partir de FormBrowser</td></tr>
<tr><td>in_admin</td><td>1 Si le formulaire est visualis&eacute; de l&#039;administration de FormBrowser</td></tr>
<tr><td>fbr_id</td><td>ID de retour si le formulaire est affich&eacute; &agrave; partir de FormBrowser</td></tr>

<tr><td>prev</td><td>Bouton &quot;Reculer&quot; pour un formulaire multiple</td></tr>
<tr><td>submit</td><td>Bouton &quot;Suivant&quot; or &quot;Envoyer&quot;  pour un formulaire multiple, ajuster automatiquement</td></tr>
</table>
<p>Je ne sais pas pourquoi vous vouliez &ccedil;a, mais les voil&agrave;...</p>
';
$lang['post_install'] = 'FormBuilder est install&eacute;. Merci de consulter l&#039;aide du module pour la documentation.';
$lang['help'] = '<h3>Que fait ce module ?</h3>
<p>Le module Form Builder vous permet de cr&eacute;er des formulaires (il s&#039;agit en fait du rempla&ccedil;ant du module Feedback Form d&#039;origine), avec la puissance suppl&eacute;mentaire du stockage sur base de donn&eacute;es. Avec son module associ&eacute; Form Browser, vous pouvez l&#039;utiliser pour cr&eacute;er des applications simples de base de donn&eacute;es.</p>
<p>Les formulaires cr&eacute;&eacute;s par le module Form Builder peuvent &ecirc;tre ins&eacute;r&eacute;s dans des gabarits et/ou des pages de contenu. Les formulaires peuvent contenir de nombreux types d&#039;entr&eacute;es, et peuvent avoir des validations appliqu&eacute;es &agrave; ces entr&eacute;es. Le r&eacute;sultat de ces formulaires peuvent &ecirc;tre g&eacute;r&eacute;s de diff&eacute;rentes mani&egrave;res.</p>

<h3>Comment l&#039;utiliser ?</h3>
<p>Installez-le, et fouinez dans les menus. Jouez avec. Essayez de cr&eacute;er des formulaires, et de les ajouter &agrave; votre contenu.
Si vous &ecirc;tes coinc&eacute;s, venez discuter avec moi sur le canal #cms sur IRC, posez une question sur le forum, envoyez-moi un email, ou, si vous &ecirc;tes vraiment d&eacute;sesp&eacute;r&eacute;, essayez de lire les instructions sur le reste de cette page.</p>

<h3>Comment cr&eacute;er un formulaire ?</h3>
<p>Dans le menu d&#039;administration du CMS, vous devriez avoir une nouvelle entr&eacute;e appel&eacute;e FormBuilder. Cliquez dessus. Dans la page qui s&#039;affiche, des options apparaissent (en bas de la liste des formulaires) pour ajouter un nouveau formulaire ou modifier la configuration.</p>

<h3>Ajouter un formulaire &agrave; une Page</h3>
<p>Dans la page principale d&#039;administration de FormBuilder, vous pouvez voir un exemple de balise utilis&eacute; pour afficher chaque formulaire. &Ccedil;a ressemble &agrave; quelque chose comme &ccedil;a : {FormBuilder form=&#039;sample_form&#039;}</p>
<p>Copier cette balise dans le contenu d&#039;une page, ou dans un gabarit, verra le formulaire affich&eacute;.
En th&eacute;orie, vous pouvez avoir de multiple formulaires dans une page si vous y tenez vraiment. Soyez vigilant si vous collez la balise dans la page du contenu &agrave; l&#039;aide d&#039;&eacute;diteurs WYSIWYG comme TinyMCE, FCKEdit, ou HTMLArea. Ces &eacute;diteurs pourraient furtivement changer le guillemet (&quot;) en entit&eacute; HTML (&amp;quot;), et les formulaires ne s&#039;afficheraient plus. Essayez d&#039;utiliser des guillemets simples (&#039;) ou &eacute;ditez directement le HTML.</p>

<h3>Travailler avec les formulaires</h3>
<p>By clicking on a Form&#039;s name, you enter the Form Edit page. There are several tabs, which are described below:</p>
<h4>Main</h4>
<p>This is the main place you&#039;ll work on your form. Here, you give it a name, an alias (which is used to identify it for placing it in a page or template), and, optionally, a CSS class with which to wrap the whole thing.</p>
<p>Below this, if you have it enabled, is the &quot;fast field adder&quot; pulldown, that lets you quickly add a field to the end of your form by selecting the field type.</p>
<p>Below this is the list of fields that make up your form. More detail on this is described below.</p>
<h4>Soumission des formulaires</h4>
<p>When the form is submitted, you can either redirect the user to another page of your site, or you can present the user some message (which can contain any of the user&#039;s form entries, or just static text). In this tab, you select which of these approaches you wish to use, and, if you chose redirection, it allows you to pick the page to redirect users to after a successful form submission.</p>
<p>Also on this page, you can specify the labels of various submission buttons (&quot;Previous&quot;, &quot;next&quot;, &quot;submit&quot;). You can also opt to have some Javascript added to the last page of a form that will prevent multiple submissions (useful on slow servers).</p>
<h4>Option d&#039;affichage du formulaire</h4>
<p>This tab allows for other form customizations, like the symbol to show for required fields.</p>
<h4>configuration Captcha</h4>
<p>If you have installed the Captcha module, this tab lets you configure the Captcha settings for your form.</p>
<h4>Gabarit de formulaire</h4>
<p>This is where you do your customization work of your form&#039;s Smarty Template. See the section called Form Template Variables below.</p>
<p>The form should default to a Custom template that documents the Smarty tags available to you.</p>
<p>Unless you&#039;re a Smarty expert, you probably don&#039;t want to mess around with this. If you are a Smarty expert, this is where you can unleash your magic.</p>
<h4>Soumission du gabarit</h4>
<p>If, in the Form Submission tab, you selected &#039;Display &quot;Submission Template&quot;, this is where you can create that template. There is a display of which smarty variables are available to you, and a button to generate a sample template.</p>
<p>If you&#039;re a Smarty expert, you can do all manner of creative and powerful things here. If you&#039;re not a Smarty expert, you might just want to use the default.
</p>

<h3>Ajouter des champs dans votre formulaire</h3>
<p>The types of fields that are currently supported fit into four groups: standard input fields, display control fields, email-specific fields, and form result handling fields (also called Form Dispositions in places):</p>
<ul>
<li>Standard Input Fields - these are inputs that allow entry of typical form elements; text inputs, radio buttons, etc.</li>
<li>Display Control Fields - these input control how the user will see the display of the form; page breaks, static text, etc.</li>
<li>Email-specific Fields - some forms generate email, and email-specific fields can alter attributes of the emails sent.</li>
<li>Form Dispositions - These determine what happens when the user
submits the form; for each result handling field, some method of transmitting, saving, or emailing the
form contents takes place. A form may have multiple form dispositions.</li>
</ul>
<p>Form fields are assigned names. These names identify the field, not only on the screen as labels for the user,
but in the data when it&#039;s submitted so you know what the user is responding to. Phrasing the name like a question
is a handy way of making it clear to the user what is expected. Similarly, many fields have both Names and Values.
The Names are what gets shown to the user; the Value is what gets saved or transmitted when the user submits
the form. The Values are never seen by the user, nor are they visible in the HTML, so it&#039;s safe to use for
email addresses and such.</p>
<p>Some fields can have multiple values, or multiple name/value pairs. When you first create such a field,
there may not be sufficient inputs for you to specify all the values you want. To get more space for inputting
these values, use the buttons at the bottom of the page for adding options.</p>
<p>Fields can be assigned validation rules, which vary according to the type of the field. These rules help
ensure that the user enters valid data. They may also be
separately marked &quot;Required&quot;, which will force the user to enter a response.</p>
<p>Fields also may be assigned a CSS class. This simply wraps the input in a div with that class, so as to allow
customized layouts. To use this effectively, you may need to &quot;view source&quot; on the generated form, and then
write your CSS.</p>
<ul>
<li>Standard Inputs
<ul><li>Text Input. This is a standard text field. You can limit the length, and apply various validation
functions to the field.</li>
<li>Text Area. This is a big, free-form text input field.</li>
<li>Checkbox. This is a standard check box.</li>
<li>Checkbox Group. This is a collection of checkboxes. The only difference between this input and a
collection of Checkbox inputs is that they are presented as a group, with one name, and can have a validation function requiring that you check one or more of the boxes in the group.</li>
<li>Radio Group. This is a collection of radio buttons. Only one of the group may be selected by the user.</li>
<li>Pulldown. This is a standard pulldown menu. It&#039;s really conceptually the same thing as a radio button
group, but is better when there are a large number of options.</li>
<li>Multiselect. This is a multi-select field. It&#039;s really conceptually the same thing as a checkbox button
group, but is better when there are a large number of options, as you can limit the number displayed on the screen at any one time.</li>

<li>Password. This is an asterisked-out text field, useful for passwords.</li>
<li>Password Again (verify). This is a field that must match a Password field for submission
to succeed.</li>

<li>State. This is a pulldown listing the States of the U.S.</li>
<li>Canadian Province. This is a pulldown listing the Canadian Provinces (Contributed by Noel McGran. Thanks!)</li>
<li>Countries. This is a pulldown listing the Countries of the world (as of July 2005).</li>
<li>Date Picker. This is a triple pulldown allowing the user to select a date.</li>
<li>Time Picker. This is a set of pulldowns allowing the user to select a time (using 12 or 24 hour clock).</li>
<li>File Upload. This is a file upload field.</li>
<li>Link (User Entered). This creates a double input field for getting a link URL and link title.</li>
<li>Text Field (Multiple). This field creates one or more text inputs with add and delete buttons, effectively giving the end user a way of creating variable-length lists.</li>
</ul></li>

<li>Email-specific Inputs
<ul><li>Email &quot;From Address&quot; Field. This allows users to provide their email address. The email generated when the form gets handled will use this address in the &quot;From&quot; field.</li>
<li>Email &quot;From Name&quot; Field. This allows users to provide their name. The email generated when the form gets handled will use this name in the &quot;From&quot; field.</li>
<li>Email Subject Field. This allows users to provide a subject for their email. The email generated when the form gets handled will use this in the &quot;Subject&quot; field. This may cause trouble with certain dispositions that want to control the Email Subject, so use it with caution.</li>
</ul></li>

<li>Display Control Fields<ul>
<li>-Page Break. This allows you to split your feedback form into multiple pages. Each page is
independently validated. This is good for applications like online surveys.</li>
<li>-Fieldset Start. Combined with Fieldset End, this allows you to group various fields within your form. Use this to start a given grouping.</li>
<li>-Fieldset End. Combined with Fieldset Start, this allows you to group various fields within your form. Use this to end a given grouping.</li>
<li>-Hidden Field. This allows you to embed a hidden field in your form.</li>
<li>-Static Text. This allows you to put text or a label in the middle of your form. This is useful for giving additional help text, especially if you&#039;re not using a Custom Template to render your form.</li>
<li>-Static Link. This allows you to put a link to a given page into your form. Optionally, you can have it autopopulate with the page where the form is embedded (useful if you&#039;re sending results via email).</li>
<li>-Computed Field. This allows you to embed a computed field in your form. It is not visible to the user until after the form is submitted. It allows you to do simple arithmetic or string concatenation.</li>
<li>-Unique Integer (Serial). This is an integer that increases every time someone hits your form. Your results may not be sequential, but they will increase monotonically.</li>
<li>-User Tag. This calls the specified User Defined Tag, and displays anything it returns. The UDT gets called any time the field would be visible.</li>
</ul></li>
<li>-Module Include Tag. This allows you to embed other module output into your form, e.g., a list of products from the Products module.</li>

<li>Form Handling Inputs (Dispositions)
<ul><li>*Call a User Defined Tag With the Form Results. This submits all the form results to the User-Defined Tag you specify. The UDT can handle the results however it wants. Values are passed as $params[&#039;field_name&#039;], and as $params[&#039;field_alias&#039;] (if defined).</li>
<li>*Email Results Based on Pulldown. This is useful for web sites where comments get routed based on their subject matter, e.g., bugs get sent to one person, marketing questions to another person, sales requests to someone else, etc. The pulldown is populated with the subjects, and each gets directed to a specific email address. You set up these mappings in the when you create or edit a field of this type. If you use one of these &quot;Director&quot; pulldowns, the user must make a selection in order to submit the
form. This input is part of the form the user sees, although the email addresses are not made visible nor
are they embedded in the HTML.</li>
<li>*Email &quot;From Address&quot; Field, and send copy. This works like the Email &quot;From Address&quot; Field described above, but it provides options for sending a copy of the results to the user.</li>
<li>*Email Results to set Address(es). This simply sends the form results to one or more email addresses that you enter when you create or edit this type of field. This field and its name are not visible in the
form that the user sees. The email addresses are not made visible nor
are they embedded in the HTML.</li>
<li>*Email to User-Supplied Address. This puts an input field in the form for the user to populate with an email address. The form results get sent to that address. Beware of Spam abuse! Active the primitive anti-spam features in the FormBuilder configuration screen.</li>
<li>*Store Results in Database. <strong>Deprecated.</strong> Use Store Results for FormBrowser Module instead! This will store the form contents in an internal database. You will always use this disposition if you use the form with FormBrowser.</li>
<li>*Redirect to Page Based on Pulldown. This allows you to redirect the form to a different site page depending on its value. If you have multiple dispositions, make sure this is used last.</li>
<li>*Validate via Email. This is a strange and powerful field. It provides the user a mandatory input for their email address. Once they submit their form, the standard form dispositions are not performed -- rather, it send the user an email with a special coded link. If they click on the link, the other form is considered &quot;approved,&quot; and the other dispositions are all performed.</li>
<li>*Write Results to Flat File. This takes the form results and writes them into a text file. You may
select the name of the file, and set its format. These files are written to the &quot;output&quot; directory under the
module&#039;s installation directory, assuming the web server has permission to write there.</li>
<li>*Write Results to a Unique Flat File for each submission. This takes the form results and writes them to a unique text file for each form submission.
You can specify a filename pattern using values from form fields, set its format, and set the directory where the files will be stored.</li>
<li>*Save Results to File Based on Pulldown. Like the Flat File disposition, except the value of a pull-down determines which file results get written to.</li>
<li>*Save Results to File(s) Based on Multiple Selections. Like the Flat File disposition, except the value(s) of checkboxes  determines which file(s) results get written to.</li>
<li>*Email to CMS Admin User. Provides a pull-down of CMS Admin users, and directs the results as an email to the selected admin.</li>
<li>*Store Results for FormBrowser Module v.0.3. Stores the form results in an XML structure as a single database record. This is the only interface to Form Browser. See section below.</li>
<li>*Submit to an arbitrary form action. Craft an HTTP GET or POST, and transmit it using cURL to the specified URL. This lets you use FormBuilder as a front-end to any CGI or Form Handling script out there.</li>

</ul></li></ul>


<h3>Passing Default Values to Forms</h3>
<p>Calguy added a nice feature, which is that you can pass default field values to your form via the module tag. This allows you to have
the same form in multiple places, but with different default values. It may not work for more exotic field types, but for fields that have
a single value, you can specify like:</p>
<p>{FormBuilder form=&#039;my_form&#039; value_<i>FIELDNAME</i>=&#039;default_value&#039;}</p>
<p>This will set the field with <i>FIELDNAME</i> to &#039;default_value&#039;.</p>
<p>This can be problematic, as sometimes field names are unweildy or contain characters that don&#039;t work well with Smarty. So there is an
alternative like this:</p>
<p>{FormBuilder form=&#039;my_form&#039; value_fld<i>NUMBER</i>=&#039;default_value&#039;}</p>
<p>That uses field <i>NUMBER</i>, where <i>NUMBER</i> is the internal FormBuilder field id. You might wonder how you know what that id is. Simply go into the FormBuilder configuration tab,
and check &quot;Show Field IDs&quot;</p>

<h3>Email and Flat File Templates</h3>
<p>Many disposition types allow you to create a template for the email that is generated, or for the way the results are written to a file. If you opt not to create a template, the FormBuilder will use its own best guess, which may or may not work out to your liking. You can always click on the &quot;Create Sample Template&quot; and then customize the results.</p>
<p>To the right, you&#039;ll find a legend which lists all of the variables that are available to you to use in your template. As of version 0.3, variables have two names, one based on the field name, the other based on the field ID. If you use field names that have characters outside of the ASCII 32-126 range, it will be safer to use the ID-based variables. As of version 0.5, variables also have aliases, which you can use.</p>
<p><strong>Note that once you&#039;ve changed a template, it will no longer automatically add new fields.</strong> For this reason, it&#039;s usually best to create your templates as the last step of creating your form.</p>
<p>As of version 0.2.4, you can opt to send any of these emails as HTML email. There should be a checkbox at the top of the template page for this. There is also a &quot;Create Sample HTML Template&quot; button over in the legend area. For HTML email, the email body will also provide the default text-only values.</p>

<h3>Use with FormBrowser v3</h3>
<p>There are some special features when using FormBuilder with FormBrowser. The new approach stores the form results in XML, so that far fewer
queries are needed to retrieve records. This means you can use FormBrowser with hundreds or even thousands of records. It also means you
will have to choose up front which fields you will want to be able to sort by. You can choose up to five. Changing these after there are submitted records will result in improper sorting! A re-index function will be added to a future version.</p>
<p>In advanced options, you can tie a form to Frontend Users. That means each user gets one record for the form; they can create it
a single time, subsequent times they will be editing their record. The record will not be visible to any other users (excluding admins).
This form should be added to your page using the syntax {FormBuilder action=&#039;feuserform&#039; form=&#039;form_name&#039;}.</p>
<p>For greater data safety, you can encrypt the stored forms in the database. You can use the built-in mycrypt library or the OpenSSL module.
In either case, for the passphrase, you can either enter text in the field or a file name. If you specify a file name, the contents of that
file will be used as the passphrase for encrypting.</p>
<p>If you encrypt, be aware that the fields you use for sorting are <strong>not</strong> encrypted. You can choose to hash them; the cheat here
is that the first four letters are left intact to allow for sorting. The sorting may not be perfect, and this weakens the security since it
exposes some cleartext, but it is better than nothing.</p>
<p><strong>DISCLAIMER</strong>. The encryption offered here should be considered just one more hurdle for a hacker, not as a guarantee that
your information will be secure. A smart hacker who has found some exploit to view database records may well be smart enough to get at
the module source code, and find their way to the passphrase. This will not protect you against an enemy who has full access to your
server, some familiarity with PHP, and the time to poke around. <em><strong>Do not</strong> use this to protect high-value information such as financial data,
sensitive political information, human rights data, or anything else that might be of value to a repressive government or organized crime
cartel.</em></p>
<h3>Using with User Defined Tags (UDTs)</h3>
<p>Several options for customizing behavior via UDTs is provided (thanks to kind code contributions, see credits).</p>

<ul><li>Call User Defined Tag With the Form Results. This field type submits the human-readable form results to the User-Defined
Tag you specify. The UDT can handle the results however it wants. Values are passed as $params[&#039;field_name&#039;], and
as $params[&#039;field_alias&#039;] (if defined). As per a suggestion, it also populates all of the Smarty values that would be visible to the Submission Template too!</li>
<li>User Tag Field. This calls the specified UDT, and displays anything it returns. The UDT gets called any time the field would be visible.</li>
<li>Validation UDT. Set this for a form, and the UDT will receive all of the form\&#039;s human-readable results. The UDT should do whatever
validation it wants, and return an array with the first value being true or false (indication whether the form validates), and the second
value being error messages (if any).</li>
<li>User defined tag to call before form is displayed the first time (only called once). This
is set in the Form Admin in the UDT Integration tab. The UDT gets called on the first display
of the form.</li>
<li>User defined tag to call before form is displayed (called on every page of multipage
forms). This is set in the Form Admin in the UDT Integration tab. The UDT gets called
every time any page of the form is displayed (including when validation fails).</li>
</ul>

<h3>Configuration</h3>
<p>There are some global configuration options for FormBuilder:</p>
<ul>
<li>Enable fast field add pulldown. This enables the pulldown on the Form Edit page which saves a step in the creation of new fields.</li>
<li>Hide Errors. This is set by default. Unchecking it will cause more detailed errors to be displayed if there are problems when you submit your form.</li>
<li>Require Field Names. Typically, you will want form fields to be named so you can tell which is which. However, in some cases, you might want to have nameless fields. Uncheck this if you want to allow nameless fields.</li>
<li>Unique Field Names. Typically, you will want form fields to have unique names so you can tell which is which. Uncheck this if you want to allow fields to share names.</li>
<li>Use relaxed email validation. This uses a less restrictive regular expression for validating email; e.g., x@y will be allowed, where typically x@y.tld is required.</li>
<li>Show Form Builder Version. Displays the version of FormBuilder you&#039;re using in a comment when the form is generated. Typically only useful when debugging.</li>
<li>Enable primitive anti-spam features. When turned on, this allows any given IP address to only generate 10 emails per hour.</li>
<li>Show Field IDs. When turned on, FormBuilder will display field ids when adding or editing a form.</li>
</ul>
<h3>Styling and CSS</h3>
<p>After a bit of nagging on the part of people who actually respect standards, FormBuilder no longer encourages tricks like embedding CSS in 
static text fields. Instead, it creates a stylesheet called &quot;FormBuilder Default&quot; that you are encouraged to attach to the page template
that you use for pages that contain your form.</p>  
<p>This default CSS was graciously provided by Paul Noone.</p>


<h3>Form Template Variables</h3>
<p>You can edit it to make your form layout look any way you&#039;d like.
   To make the form work, you&#039;ll need to always include the {$fb_hidden} and {$submit}
   tags.</p>

<p>You can access your form fields either using the $fields array or by directly accessing fields by their names (e.g., {$myfield->input} )</p>


<p>Each field has the following attributes:</p>
<table>
<tr><th>Field</th><th>Value</th></tr>
<tr><td>field->display</td><td>1 if the field should be displayed, 0 otherwise</td></tr>
<tr><td>field->required</td><td>1 if the field is required, 0 otherwise</td></tr>
<tr><td>field->required_symbol</td><td>the symbol for required fields</td></tr>
<tr><td>field->css_class</td><td>the CSS class specified for this field</td></tr>
<tr><td>field->valid</td><td>1 if this field has passed validation, 0 otherwise</td></tr>
<tr><td>field->error</td><td>Text of the validation problem, in the event that this field did not validate</td></tr>
<tr><td>field->hide_name</td><td>1 if the field name should be hidden, 0 otherwise</td></tr>
<tr><td>field->has_label</td><td>1 if the field type has a label</td></tr>
<tr><td>field->needs_div</td><td>1 if the field needs to be wrapped in a DIV (or table row, if that&#039;s the way you swing)</td></tr>
<tr><td>field->name</td><td>the field&#039;s name</td></tr>
<tr><td>field->input</td><td>the field&#039;s input control (e.g., the input field itself)</td></tr>
<tr><td>field->op</td><td>a control button associated with the field if applicable (e.g., the delete button for expandable text input)</td></tr>
<tr><td>field->input_id</td><td>the ID of the field&#039;s input (useful for label for=&quot;foo&quot;)</td></tr>
<tr><td>field->type</td><td>the field&#039;s data type</td></tr>
                                
<tr><td>field->multiple_parts</td><td>1 if the field->input is actually a collection of controls</td></tr>
<tr><td>field->label_parts</td><td>1 if the collection of controls has separate labels for each control</td></tr>
</table>

<p>In certain cases, field->input is actually an array of objects rather than an input. This happens, for example, in CheckBoxGroups or RadioButtonGroups. For them, you can iterate through field->input->name and field->input->inputs.</p>
    
<p>Additional smarty variables that you can use include:</p>
<table>
<tr><th>Variable</th><th>Value</th></tr>
<tr><td>total_pages</td><td>number of pages for multi-page forms</td></tr>
<tr><td>this_page</td><td>number fo the current page for multi-page forms</td></tr>
<tr><td>title_page_x_of_y</td><td>displays &quot;page x of y&quot; for multi-page forms</td></tr>
<tr><td>css_class</td><td>CSS Class for the form</td></tr>
<tr><td>form_name</td><td>Form name</td></tr>
<tr><td>form_id</td><td>Form database ID</td></tr>
<tr><td>prev</td><td>&quot;Back&quot; button for multipart forms</td></tr>
<tr><td>submit</td><td>&quot;Continue&quot; or &quot;Submit&quot; button for multipart forms, adjusts automatically</td></tr>
</table>
<p>Dunno why you&#039;d want some of those, but there you go...</p>

<h3>Credits</h3>
<p>Many people have contributed code, bug reports, cash, and ideas to FormBuilder. Among them (alphabetically):
<ul>
<li><a href="http://www.bpti.eu">Baltic institute of advanced technology</a> - code, funding </li>
<li>Jeremy Bass - code and suggestions</li>
<li>Alberto Benati - code</li>
<li>Tyler Boespflug - funding and ideas</li>
<li>Jeff Bosch - UDT Validation</li>
<li>Robert Campbell - numerous code contributions</li>
<li>Piotras Cimmperman - code</li>
<li>Nuno Costa - suggestions</li>
<li>Ryan Foster - code</li>
<li>Marc Geldon - code</li>
<li>Kevin Grandon - code</li>
<li>Ronny Krijt - code</li>
<li>Paul Noone - CSS and ideas</li>
<li>Morten Poulsen - code</li>
<li>Prue Rowland - bug fixes</li>
<li>Simon Schaufelberger - code</li>
</ul>
<p>I apologize for any omissions - notify me, and I&#039;ll correct the omission!</p>
<h3>Miscellaneous Notes</h3>
<ul>
<li>Any fields that sends email to a specified email address will also accept a comma-separated list of email addresses.</li>
</ul>
<h3>Known Issues</h3>
<ul>
<li>FormBuilder does not yet support pretty URLs, although that shouldn&#039;t matter since the user side is pretty simple.</li>
<li>FileUpload Fields may not work correctly with multipage forms.</li>
</ul>

<h3>Troubleshooting</h3>
<ol><li> First step is to check you&#039;re running CMS 1.1 or later.</li>
<li> Second step is to read and understand the caveat about WYSIWYG editors up in the
section <em>Adding a Form to a Page</em>.</li>
<li> If you&#039;re missing fields in an email that gets generated, check the disposition field&#039;s template, and make sure you&#039;re specifying the missing fields. Seems obvious, but it&#039;s an easy mistake to make.</li>
<li>Uncheck the &quot;Hide Errors&quot; checkbox in the global options, and see what message gets displayed when you submit your form.</li>
<li> Just mess around and try clicking on links and icons and stuff. See what happens.</li>
<li> Make sure you can successfully send email via the test in the CMSMailer Module. It&#039;s simply amazing how many problems boil down to a misconfigured CMSMailer.</li>
<li> Last resport is to email me or catch me on IRC and we can go from there.</li>
</ol> 
<p>This is no longer a particularly early version, but it is probably still buggy. While I&#039;ve done all I can
to make sure no egregious bugs have crept in, I have to admit that during early testing, this program
revealed seven cockroaches, two earwigs, a small family of aphids, and a walking-stick insect. It also
ate the neighbor&#039;s nasty little yap dog, for which I was inappropriately grateful.</p>
<p>The final release will include bug fixes, documentation, and unconditional love.</p>
<h3>Support</h3>
<p>Ce module ne contient aucun support commercial. Cependant, ces ressources sont disponibles pour vous aider :</p>
<ul>
<li>Pour la derni&egrave;re version de ce module, les FAQs, ou pour annoncer un bug, veuillez visiter le site CMS Made Simple  <a href="http://dev.cmsmadesimple.org">Developer Forge</a>.</li>
<li>pour obtenir un support commercial, merci de contacter l&#039;auteur par mail <a href="mailto:sjg@cmsmodules.com">sjg@cmsmodules.com</a>.</li>
<li>Des discussions compl&eacute;mentaires relatives &agrave; ce module peuvent aussi &ecirc;tre trouv&eacute;es sur les <a href="http://forum.cmsmadesimple.org">Forums CMS Made Simple</a>.</li>
<li>L&#039;auteur,est souvent sur IRC sur canal <a href="irc://irc.freenode.net/#cms">CMS IRC Channel</a>.</li>
<li>Et enfin, vous pouvez rencontrer un certain succ&egrave;s en envoyant un email directement &agrave; l&#039;auteur.</li>
<li>Donations are good motivators, too. Keep in mind that the dollar is weak, and if you are not in the US, your donation gets magnified.</li>
</ul>
<p>Keep in mind that the author has put <em>hundreds and hundreds of hours</em> into the development of this module.
Please take the time to read the documentation before sending questions. Either that, or send your questions written on
financially negotiable instruments (i.e., checks or cash). Am I sounding like a broken record? Do you kids these days
even know what a broken record is? I would say skipping CD, but you might not know what that is either. Like a
sample that got stuck on loop? Damn, I am getting old. So is this paragraph. Time to move on, here.</p><form action=&quot;https://www.paypal.com/cgi-bin/webscr&quot; method=&quot;post&quot;>
<input type=&quot;hidden&quot; name=&quot;cmd&quot; value=&quot;_s-xclick&quot;>
<input type=&quot;image&quot; src=&quot;https://www.paypal.com/en_US/i/btn/btn_donateCC_LG.gif&quot; border=&quot;0&quot; name=&quot;submit&quot; alt=&quot;PayPal - The safer, easier way to pay online!&quot;>
<img alt=&quot;&quot; border=&quot;0&quot; src=&quot;https://www.paypal.com/en_US/i/scr/pixel.gif&quot; width=&quot;1&quot; height=&quot;1&quot;>
<input type=&quot;hidden&quot; name=&quot;encrypted&quot; value=&quot;-----BEGIN PKCS7-----MIIHTwYJKoZIhvcNAQcEoIIHQDCCBzwCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYAINnBWb/XM4lmvLGHl9Rd1cvL5trqRhc7+FoGH5LtofQiVrgFSvh7h1ojg5SzTxbgti32ZF0/ucuq/OQSD+VzuuAF1v6wVrtyOeCPEAw8j81DJOXVjJHsIY2mviorPjolLQkFnv12yRTpuFWFn4ZXe5+vnCjXqBy0EE/ahzEMMnzELMAkGBSsOAwIaBQAwgcwGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIcKNNwOPFowuAgaivS7v0j2XFyQ9dr8ni9G95eE7YqogGlK9wuSpllOg9lnruvnEQqsmRmQnthQqWCTbZzG2+IEteM4IUsxEuGTrw8pZCU24TNDcknKUx9Uz3vSxOh3gu95yJyDwoeMvaEA24bs14QEbJbhNjY6WxHz9+i/lVADBjyAODYMuzalDkvduvweGNZk9lYLRRCoPPNilG1Pf6w87BHpkSM8WQ1LC9+RWdXfZcm+egggOHMIIDgzCCAuygAwIBAgIBADANBgkqhkiG9w0BAQUFADCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wHhcNMDQwMjEzMTAxMzE1WhcNMzUwMjEzMTAxMzE1WjCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAMFHTt38RMxLXJyO2SmS+Ndl72T7oKJ4u4uw+6awntALWh03PewmIJuzbALScsTS4sZoS1fKciBGoh11gIfHzylvkdNe/hJl66/RGqrj5rFb08sAABNTzDTiqqNpJeBsYs/c2aiGozptX2RlnBktH+SUNpAajW724Nv2Wvhif6sFAgMBAAGjge4wgeswHQYDVR0OBBYEFJaffLvGbxe9WT9S1wob7BDWZJRrMIG7BgNVHSMEgbMwgbCAFJaffLvGbxe9WT9S1wob7BDWZJRroYGUpIGRMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbYIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAIFfOlaagFrl71+jq6OKidbWFSE+Q4FqROvdgIONth+8kSK//Y/4ihuE4Ymvzn5ceE3S/iBSQQMjyvb+s2TWbQYDwcp129OPIbD9epdr4tJOUNiSojw7BHwYRiPh58S1xGlFgHFXwrEBb3dgNbMUa+u4qectsMAXpVHnD9wIyfmHMYIBmjCCAZYCAQEwgZQwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tAgEAMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wODA3MDEwMzU5MzlaMCMGCSqGSIb3DQEJBDEWBBQM0LV30fLXcH9M5dMmuTBLnsFQ4jANBgkqhkiG9w0BAQEFAASBgBEz2XqMMqFbuUhj+L128Cw2u8ShOKQttrKr/hi0WReenHDYBiHOStl63Rv76Q2mpd453RvCj5mq7dRtuRB6pfHGRDkUX6N1+OOIoIfroBZIATNhz9CEHwEFkNjYg0EGMAG+jcbAj1DJjR73cxbaNrXWPxA+hiQhHlArrZA7rFV5-----END PKCS7-----
&quot;> 
</form>
<p>As per the GPL, this software is provided as-is. Please read the text
of the license for the full disclaimer.</p>
<h3>Copyright and License</h3>
<p>Copyright &amp;copy; 2009, Samuel Goldstein <a href="mailto:sjg@cmsmodules.com">&amp;lt;sjg@cmsmodules.com&amp;gt;</a>. All Rights Are Reserved.</p>
<p>Ce module est distribu&eacute; sous la licence <a href="http://www.gnu.org/licenses/licenses.html#GPL">GNU Public License</a>. Vous devez agr&eacute;er aux termes de cette licence pour pouvoir utiliser ce module.</p>';
$lang['qca'] = 'P0-483686814-1251229608352';
$lang['utma'] = '57867837.1772960952774974200.1251229608.1315083144.1315177962.175';
?>